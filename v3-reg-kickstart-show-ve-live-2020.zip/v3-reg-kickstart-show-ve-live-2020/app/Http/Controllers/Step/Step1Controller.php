<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use RegCore\Http\Controllers\Step;

// For having demographics on first page use `extends Step\Step1withDemoController`
class Step1Controller extends Step\Step1Controller
{
    use Traits\Flow;
    use Traits\Step;
}
