<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use RegCore\Http\Controllers\Step;

class Step5Controller extends Step\Step5Controller
{
    use Traits\Flow;
    use Traits\Step;
}
