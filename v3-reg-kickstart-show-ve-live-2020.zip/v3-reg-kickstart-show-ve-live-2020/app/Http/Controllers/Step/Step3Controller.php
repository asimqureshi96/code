<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use RegCore\Http\Controllers\Step;

class Step3Controller extends Step\Step3Controller
{
    use Traits\Flow;
    use Traits\Step;
}
