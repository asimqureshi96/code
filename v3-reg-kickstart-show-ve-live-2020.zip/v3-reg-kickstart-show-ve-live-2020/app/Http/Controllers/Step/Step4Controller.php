<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use RegCore\Http\Controllers\Step;

class Step4Controller extends Step\Step4Controller
{
    use Traits\Flow;
    use Traits\Step;
}
