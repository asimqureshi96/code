<?php

namespace App\Http\Controllers;

use App\Http\Traits\Flow;
use RegCore\Http\Controllers as Core;

class LangController extends Core\LangController
{
    use Flow;
}
