<?php

namespace App\Http\Controllers;

use RegCore\Http\Controllers as Core;

class LookupController extends Core\LookupController
{

}
