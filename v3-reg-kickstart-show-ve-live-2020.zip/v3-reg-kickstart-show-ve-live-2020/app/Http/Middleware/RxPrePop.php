<?php

namespace App\Http\Middleware;

use Closure;

class RxPrePop
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     *
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (request()->has('queryToken')) {
            session()->put('rx_template_token', $request->input('queryToken'));
            session()->put('rx_campaign_id', $request->input('CampaignId'));

            return redirect(route('rx-pre-pop', array_except(request()->query(), ['queryToken'])));
        }

        return $next($request);
    }
}
