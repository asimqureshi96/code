<?php

namespace App\Http\Middleware;

use RegCore\Http\Middleware;

class LoadSeminar extends Middleware\LoadSeminar
{
}
