<?php

namespace App\Http\Traits;

use RegCore\Http\Traits\Flow as BaseFlow;

trait Flow
{
    use BaseFlow;

    // Copy methods from BaseFlow if you need changing them
    // Paste them below this comment
}
