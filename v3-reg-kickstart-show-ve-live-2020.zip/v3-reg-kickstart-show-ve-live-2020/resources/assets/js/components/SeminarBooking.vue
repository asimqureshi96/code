<template>
    <a
        :class="classes"
        :href="getHref(seminar)"
        @click.prevent="actionOnSeminar(seminar, getHref(seminar));"
    >
        <slot />
    </a>
</template>

<script>
export default {
    props: {
        seminar: {
            type: Object,
            required: true,
        },
        seminarUrls: {
            type: Object,
            required: true,
        },
        directBooking: {
            type: Boolean,
            default: true,
        },
        classes: {
            type: String,
            default: '',
        },
    },
    methods: {
        getHref(seminar) {
            let urls = this.seminarUrls.free;

            if (seminar.product !== null) {
                urls = this.seminarUrls.paid;
            }

            if (this.directBooking) {
                if (seminar.lead_attendee_booking === null) {
                    if (seminar.canAttachSeminar) {
                        return `${urls.attachUrl}/${seminar.id}`;
                    }

                    return null;
                }

                if (seminar.canDetachSeminar) {
                    console.log('canDetachSeminar');
                    return `${urls.detachUrl}/${seminar.id}`;
                }

                return null;
            }

            return `${urls.seminarUrl}/${seminar.id}`;
        },
        actionOnSeminar(seminar, href) {
            if (href) {
                if (this.directBooking && seminar.lead_attendee_booking === null) {
                    let urls = this.seminarUrls.free;

                    if (seminar.product !== null) {
                        urls = this.seminarUrls.paid;
                    }

                    Ajax.get(
                        `${urls.hasOverlappingMeeting}/${seminar.id}`,
                        {},
                        { withGlobalLoading: true },
                    ).then(jsonResponse => {
                        if (jsonResponse.overlapping) {
                            window.Message.getConfirm(
                                'You have meeting during same time as seminar. Do you want to proceed?',
                            ).then(() => {
                                document.location.href = href;
                            });
                        } else {
                            document.location.href = href;
                        }
                    });
                } else {
                    document.location.href = href;
                }
            }
        },
    },
};
</script>
