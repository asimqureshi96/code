<template>
    <div class="row">
        <div class="col-xl-3">
            <label class="buzz-input">
                <select
                    v-if="renderQuantity"
                    v-model="quantity"
                >
                    <option
                        :value="option"
                        v-for="option in options"
                    >
                        {{ option }}
                    </option>
                </select>

                <div class="buzz-input__select-icon">
                    <i class="fa fa-chevron-down"></i>
                </div>
            </label>
        </div>

        <div class="col-xl-3">
            <ajax-link :href="url">
                <slot></slot>
            </ajax-link>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        href: {
            type: String,
            required: true,
        },
        renderQuantity: {
            type: Boolean,
            default: true,
        },
        options: {
            type: Array,
            default() {
                return ['1', '2', '3', '4', '5', '10'];
            },
        },
    },
    data() {
        return {
            quantity: '1',
        };
    },
    computed: {
        url() {
            return `${this.href}/${this.quantity}`;
        },
    },
};
</script>
