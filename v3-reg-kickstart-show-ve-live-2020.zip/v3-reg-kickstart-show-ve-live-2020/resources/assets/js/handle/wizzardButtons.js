module.exports = function() {
    function enableSubmit($form) {
        const $next = $form.find('[data-buzz-wizard="next"]');

        if ($next.length > 0) {
            $next.addClass('d-none').removeClass('btn-block');

            $form
                .find('[data-buzz-wizard="submit"]')
                .removeClass('d-none')
                .addClass('d-btn-block');
        }
    }

    window.eventBus.$on('enable-submit', () => {
        const $form = $('[data-buzz-wizard="next"]').closest('form');
        enableSubmit($form);
    });

    $(document).on('change keydown', '[data-buzz-wizard="form"] :input', function() {
        const $form = $(this).closest('form');
        enableSubmit($form);
    });

    $(document).on('click', '[data-buzz-wizard="next"]', function(event) {
        const $form = $(this).closest('form');
        const $next = $form.find('[data-buzz-wizard="next"]');
        const $fields = $form
            .find('input,textarea,select')
            .filter('[required]:visible')
            .filter(function() {
                return !this.value;
            });

        if ($fields.length > 0 && $next.length > 0) {
            event.preventDefault();
            enableSubmit($form);
            $form.submit();
        }
    });
};
