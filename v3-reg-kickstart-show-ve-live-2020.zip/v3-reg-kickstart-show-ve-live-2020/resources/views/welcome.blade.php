<script
    src="https://code.jquery.com/jquery-3.4.1.js"
    integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
    crossorigin="anonymous"></script>
@extends('layout/center-column')

@section('content')
    <div class="text-center">
        <div class="grey-section mb-4">
            <h3 class="welcometext">
               Welcome to Venues + Events Live!
            </h3>
                <h4 class="welcometext">The unmissable show for event organisers!</h4>
        </div>
        <div class="homecontpics text-center mb-4">
            <div class="containertwo ml-5">
                <img
                    id="homeimagetwo"
                    src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/ocean-media/campaign/0aad5e6e-435b-11ea-a207-000000000000/london-192.png"
                    style="width: 500px; height: 340px;">
                <a
                    style="text-decoration: none"
                    href="https://ve-london-2020.reg.buzz"
                    target="_blank"
                >
                    <div class="centeredtwo"  id="centeredtwo">L O N D O N</div></a>
            </div>
        <div class="containerone ml-4 mb-4">
            <img id="homeimageone"
                src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/ocean-media/campaign/0aad5e6e-435b-11ea-a207-000000000000/man_home_image.jpg"
                style="width: 500px; height: 340px;">
            <a
                style="text-decoration: none"
                href="https://ve-manchester-2020.reg.buzz"
                target="_blank"
            >
                <div class="centeredone" id="centeredone">M A N C H E S T E R</div> </a>
        </div>

        </div>

        <div class="text-center mobileFooter">

            <div class="welcomeButtons">
                <a
                    href="https://ve-london-2020.reg.buzz"
                    target="_blank"

                >
                    <p class="welcomeButtonsText mt-3">London</p> </a>
            </div>
            <div class="welcomeButtons mt-2 mb-2" >
                <a
                    href="https://ve-manchester-2020.reg.buzz"
                    target="_blank"

                >
                    <p class="welcomeButtonsText mt-3">Manchester</p> </a>
            </div>



        </div>
        </div>
@endsection
<script>
$(document).ready(function(){
    $("#centeredone").mouseenter(function(){
        $("#centeredone").addClass("centeredonehover");
        $("#homeimageone").addClass("homeimageonehover");
    });
    $("#homeimageone").mouseleave(function(){
        $("#centeredone").removeClass("centeredonehover");
        $("#homeimageone").removeClass("homeimageonehover");
    });
    $("#centeredtwo").hover(function(){
        $("#centeredtwo").addClass("centeredtwohover");
        $("#homeimagetwo").addClass("homeimagetwohover");
    });
    $("#homeimagetwo").mouseleave(function(){
        $("#centeredtwo").removeClass("centeredtwohover");
        $("#homeimagetwo").removeClass("homeimagetwohover");
    });

});
</script>
