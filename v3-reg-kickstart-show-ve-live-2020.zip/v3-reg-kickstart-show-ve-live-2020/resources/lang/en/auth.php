<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed'              => 'These credentials do not match our records.',
    'throttle'            => 'Too many login attempts. Please try again in :seconds seconds.',

    // Dupe customer error
    'error_dupe_customer' => sprintf(
        '%s <a href="%s">Login here</a> or email us at %s if you need assistance.',
        'According to our records a booking has already been created using these details! Please',
        Route::has('auth::login') ? route('auth::login') : '',
        sprintf(
            '<a href="mailto:%1$s?subject=duplicate-registration">%1$s</a>',
            sprintf('%1$s@livebuzz.co.uk', config('buzz.campaign'))
        )
    ),
    'error_dupe_customer_onsite' => sprintf(
        '%s %s',
        'According to our records, the email address provided has already been used.',
        'Please see a member of staff for assistance.'
    ),
];
