<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed'              => 'Credenziali non corrispondenti ai dati registrati.',
    'throttle'            => 'Troppi tentativi di accesso. Riprova tra :seconds secondi.',

    // Dupe customer error
    'error_dupe_customer' => sprintf(
        '%s <a href="%s">Accedi qui</a> ou écrivez-nous à %s se hai bisogno di assistenza.',
        'Secondo i nostri registri, una prenotazione è già stata creata utilizzando questi dettagli! per favore',
        Route::has('auth::login') ? route('auth::login') : '',
        sprintf(
            '<a href="mailto:%1$s?subject=duplicate-registration" target="_blank">%1$s</a>',
            sprintf('%1$s@livebuzz.co.uk', config('buzz.campaign'))
        )
    ),
    'error_dupe_customer_onsite' => sprintf(
        '%s %s',
        'Secondo i nostri dati, l\'indirizzo email fornito è già stato utilizzato.',
        'Si prega di consultare un membro dello staff per assistenza.'
    ),
];
