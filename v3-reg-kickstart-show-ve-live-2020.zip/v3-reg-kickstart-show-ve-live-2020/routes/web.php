<?php

Route::get('/reg-closed', 'HomeController@regClosed')->name('reg-closed');

Route::any('/validate', 'HomeController@rxPrePop')->name('rx-pre-pop');

Route::group([
    'prefix'     => 'auth',
    'namespace'  => 'Auth',
    'as'         => 'auth::',
    'middleware' => ['lang-select'],
], function () {
    Route::get('login-via-token/{token}', 'AuthController@getLoginViaToken')->name('login-via-token');
});

Route::group(['middleware' => ['form-closed', 'lang-select']], function () {
    foreach (File::files(__DIR__ . '/others') as $route_partial) {
        require($route_partial);
    }

    Route::group(['middleware' => 'auth'], function () {
        foreach (File::files(__DIR__ . '/authenticated') as $route_partial) {
            require($route_partial);
        }
    });

    Route::get('/new-reg', 'HomeController@newReg')->name('new-reg');

    /**
     * Affiliate parameter used in Affiliate middleware
     */
    Route::get('/{affiliate?}', 'HomeController@index')->name('home')->middleware('guest');
});
