<?php

if (!config('buzz.paid_show')) {
    return;
}

Route::get('/products', 'ProductController@index')->name('products');
Route::get('/product/{product_id}/add/{customer_id?}', 'ProductController@add')->name('product::add');
Route::get('/product/{product_id}/add-quantity/{quantity?}', 'ProductController@addQuantity')
    ->name('product::add-quantity');
