<?php

Route::group(['prefix' => 'profile'], function () {
    Route::get('/', 'ProfileController@render')->name('profile');
});

Route::get('/thanks', 'ProfileController@render')->name('thanks');
