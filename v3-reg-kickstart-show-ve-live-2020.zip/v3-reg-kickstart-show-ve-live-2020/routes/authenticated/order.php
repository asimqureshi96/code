<?php

if (!config('buzz.paid_show')) {
    return;
}

Route::get('orders', 'OrderController@index')->name('orders');
