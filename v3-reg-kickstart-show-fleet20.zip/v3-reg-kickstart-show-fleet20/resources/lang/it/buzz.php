<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Buzz config translations
    |--------------------------------------------------------------------------
     */

    'event'                     => [
        'name'  => 'KickStart',
        'year'  => '2017',
        'date'  => '4 ° e 5 ° mese',
        'venue' => 'Luogo, Città',
    ],

    // Email invite
    'email_invite_subject'      => "Unisciti a KickStart",
    'email_invite_message'      => "Sto per KickStart. Unisciti a me alla mostra annuale innovativa e interattiva per chiunque fonti, acquista o serve bevande nel commercio in licenza.",

    // Linkedin intivete
    'connection_invite_subject' => "Unisciti a KickStart",
    'connection_invite_message' => "Ho appena registrato per #kickstart! Chi è venuto? @kickstart. \n\nhttps: //kickstart-visitor.localhost/?invite=INVITE_CODE",

    // Twitter invite
    'twitter_share_message'     => 'Ho appena registrato per #kickstart! Chi è venuto? @kickstart.',

];
