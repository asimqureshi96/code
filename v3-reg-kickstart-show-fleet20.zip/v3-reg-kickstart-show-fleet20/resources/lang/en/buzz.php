<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Buzz config translations
    |--------------------------------------------------------------------------
     */

    'event'                     => [
        'name'  => 'Fleet & Mobility Live',
        'year'  => '2020',
        'date'  => '6th & 7th October',
        'venue' => 'NEC, Birmingham',
    ],

    'meta_description'          => "Register now for Fleet & Mobility Live 2020",

    // Email invite
    'email_invite_subject'      => "Join me at Fleet & Mobility Live 2020",
    'email_invite_message'      => "I'm going to Fleet & Mobility Live 2020. Join me at the UK’s largest fleet annual exhibition.",

    // Linkedin invite
    'connection_invite_subject' => "Join me at Fleet & Mobility Live 2020",
    'connection_invite_message' => "I’ve just registered for #FleetLive! Who’s coming? @FleetLive.\n\nhttps://kickstart-visitor.localhost/?invite=INVITE_CODE",
    'linkedin_share_message'    => 'I’ve just registered for #FleetLive! Who’s coming? @FleetLive.',

    // Twitter invite
    'twitter_share_message'     => 'I’ve just registered for #FleetLive! Who’s coming? @FleetLive.',

];
