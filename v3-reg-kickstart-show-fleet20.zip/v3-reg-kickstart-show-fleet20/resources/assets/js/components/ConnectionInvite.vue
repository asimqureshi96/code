<template>
    <modal
        @close="close()"
        v-if="show"
    >
        <template slot="title">
            <h4 class="modal-title">
                {{ transUi('Invite') }} {{ value.name }}
            </h4>
        </template>

        <template slot="body">
            <div class="form-group">
                <label>
                    {{ transUi('Subject') }}
                </label>

                <input
                    :placeholder="transUi('Enter subject')"
                    class="form-control"
                    data-autofocus
                    type="text"
                    v-model="subject"
                />
            </div>

            <div class="form-group">
                <label>
                    {{ transUi('Message') }}
                </label>

                <textarea
                    :placeholder="transUi('Enter message')"
                    class="form-control"
                    name="message"
                    v-model="message"
                ></textarea>
            </div>
        </template>

        <template slot="buttons">
            <button
                :class="{'btn' : true, 'btn-primary': true, 'loading' :loading}"
                :disabled="!isConnectionInviteValid || loading"
                @click.prevent="sendConnectionInvite"
                type="button"
            >
                {{ transUi('Send invite') }}
            </button>
        </template>
    </modal>
</template>

<script>
export default {
    props: {
        show: {
            type: Boolean,
            required: true,
        },
        value: {
            type: Object,
        },
        inviteConnectionUrl: {
            type: String,
            required: true,
        },
    },
    data() {
        return {
            loading: false,
            message: '',
            subject: '',
        };
    },
    created() {
        this.message = this.transUi('connection_invite_message');
        this.subject = this.transUi('connection_invite_subject');
    },
    computed: {
        isConnectionInviteValid() {
            return !!(this.subject && this.message);
        },
    },
    methods: {
        sendConnectionInvite() {
            if (this.isConnectionInviteValid) {
                this.loading = true;

                const data = {
                    connection: this.value,
                    message: this.message,
                    subject: this.subject,
                };

                Ajax.post(this.inviteConnectionUrl, data)
                    .then(() => {
                        this.loading = false;
                        data.connection.invited = true;
                        this.$emit('input', data.connection);
                        this.close();
                    })
                    .catch((error) => {
                        this.loading = false;
                        this.$emit('error', error);
                    });
            }
        },
        close() {
            this.message = this.transUi('connection_invite_message');
            this.subject = this.transUi('connection_invite_subject');
            this.$emit('close');
        },
    },
};
</script>
