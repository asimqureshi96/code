<script>
export default {
    // @todo remove file after buzz-ui integrated
    props: {
        name: {
            type: String,
            default: '',
        },
        label: {
            type: String,
            default: null,
        },
        placeholder: {
            type: String,
            default: '',
        },
        required: {
            type: Boolean,
            default: false,
        },
        disabled: {
            type: Boolean,
            default: false,
        },
        value: {
            type: String,
            default: '',
        },
        errorIdentifier: {
            type: String,
            default: '',
        },
        withLabel: {
            type: Boolean,
            default: true,
        },
    },
    created() {
        this.localValue = this.value;

        if (this.localValue === null) {
            this.localValue = '';
        }
    },
    watch: {
        value() {
            this.localValue = this.value;

            if (this.localValue === null) {
                this.localValue = '';
            }
        },
    },
    methods: {},
    computed: {
        placeholderText() {
            const text = this.placeholder || this.label;

            return this.required ? `${text} *` : text;
        },
        labelText() {
            return this.label || this.placeholder;
        },
        myErrorIdentifier() {
            let identifier = this.errorIdentifier || this.name;

            identifier = _.replace(identifier, /\[/g, '.');
            identifier = _.replace(identifier, /]/g, '');

            return identifier;
        },
        myModel: {
            set(value) {
                this.localValue = value;
                this.$emit('input', value);
            },
            get() {
                return this.localValue;
            },
        },
        isInvalid() {
            return !_.isEmpty(store.state.formErrors[this.myErrorIdentifier]) ? ' is-invalid' : '';
        },
        labelVisible() {
            return this.withLabel && !!this.myModel;
        },
    },
};
</script>
