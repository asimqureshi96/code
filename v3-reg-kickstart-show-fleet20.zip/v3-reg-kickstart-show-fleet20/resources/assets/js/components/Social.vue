<template>
    <div>
        <loading
            :text="transUi('Social module loading. Please wait.')"
            v-if="loading"
        />

        <div v-else>
            <div v-if="connections">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="text-right">
                            <div class="input-group">
                                <input
                                    :placeholder="transUi('Enter email address')"
                                    @keyup.enter="triggerEmailInvite()"
                                    class="form-control"
                                    v-model="emailInviteAddress"
                                />

                                <span class="input-group-btn">
                                    <button
                                        :disabled="!isEmailValid(emailInviteAddress)"
                                        @click.prevent="triggerEmailInvite()"
                                        class="btn btn-success"
                                    >
                                        <i class="fa fa-envelope-o"></i>
                                        {{ transUi('Invite via email') }}
                                    </button>
                                </span>
                            </div>
                        </div>

                        <email-invite
                            :email="emailInviteAddress"
                            :invite-email-url="inviteEmailUrl"
                            :show="emailInviteModelVisibility"
                            @close="resetEmailInvite()"
                            ref="emailInvite"
                            v-model="emailInvites"
                        />
                    </div>
                </div>

                <div class="row justify-content-center mt-3">
                    <div
                        class="col-md-6"
                        v-if="noninvitedConnections.length"
                    >
                        <div>
                            <h5>
                                {{ transUi('Invite your connections') }}
                            </h5>

                            <div>
                                <div class="form-group">
                                    <input
                                        :placeholder="transUi('Filter connections')"
                                        class="form-control"
                                        v-model="search"
                                    />
                                </div>

                                <social-connections
                                    :connections="noninvitedFilteredConnections"
                                    :invite-connection-url="inviteConnectionUrl"
                                />

                                <div
                                    class="alert alert-warning"
                                    v-show="noninvitedFilteredConnections.length === 0"
                                >
                                    {{ transUi('None of your connections are matching filter') }}!
                                </div>
                            </div>
                        </div>
                    </div>

                    <div
                        class="col-md-6"
                        v-if="canSeeRightSide"
                    >
                        <div v-if="registeredConnections.length || registeredEmailInvites.length">
                            <h5>
                                {{ transUi('People you know that should be coming') }}
                            </h5>

                            <div
                                class="row"
                                style="max-height:310px;overflow:auto;"
                            >
                                <div
                                    class="col-md-3"
                                    v-for="connection in registeredConnections"
                                >
                                    <connection-item :connection="connection"/>
                                </div>

                                <div
                                    class="col-md-3"
                                    v-for="invite in registeredEmailInvites"
                                >
                                    <invite :invite="invite"/>
                                </div>
                            </div>

                            <br/>
                        </div>

                        <div v-if="invitedConnections.length || nonregisteredEmailInvites.length">
                            <h5>
                                {{ transUi('Your pending invites') }}
                            </h5>

                            <div>
                                <div
                                    class="row"
                                    style="max-height:310px;overflow:auto;"
                                >
                                    <div
                                        class="col-md-3"
                                        v-for="connection in invitedConnections"
                                    >
                                        <connection-item :connection="connection"/>
                                    </div>

                                    <div
                                        class="col-md-3"
                                        v-for="invite in nonregisteredEmailInvites"
                                    >
                                        <invite :invite="invite"/>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="well"></div>
            </div>
        </div>
    </div>
</template>

<script>
import ConnectionItem from './ConnectionItem.vue';
import EmailInvite from './EmailInvite.vue';
import Invite from './Invite.vue';
import SocialConnections from './SocialConnections.vue';

export default {
    props: {
        suggestUrl: {
            type: String,
            required: true,
        },
        inviteConnectionUrl: {
            type: String,
            required: true,
        },
        inviteEmailUrl: {
            type: String,
            required: true,
        },
        buzzConfig: {
            type: Object,
            required: true,
        },
    },
    components: {
        ConnectionItem,
        EmailInvite,
        Invite,
        SocialConnections,
    },
    data() {
        return {
            connections: null,
            emailInvite: null,
            emailInviteAddress: null,
            emailInviteModelVisibility: false,
            emailInvites: [],
            loading: true,
            search: '',
        };
    },
    created() {
        this.fetchSuggestions();
    },
    computed: {
        canSeeRightSide() {
            return (
                !_.isEmpty(this.invitedConnections) ||
                !_.isEmpty(this.nonregisteredEmailInvites) ||
                !_.isEmpty(this.registeredConnections) ||
                !_.isEmpty(this.registeredEmailInvites)
            );
        },
        noninvitedFilteredConnections() {
            return this.noninvitedConnections.filter(connection => (
                connection.name.toLowerCase().indexOf(this.search.toLowerCase()) !== -1
            ));
        },
        noninvitedConnections() {
            return this.connections.filter(connection => (
                !connection.invited &&
                !connection.exists &&
                connection.provider === 'linkedin'
            ));
        },
        invitedConnections() {
            return this.connections.filter(connection => (connection.invited && !connection.exists));
        },
        registeredConnections() {
            return this.connections.filter(connection => connection.exists);
        },
        registeredEmailInvites() {
            return this.emailInvites.filter(connection => (
                connection.status === 'accepted' ||
                connection.status === 'bypassed'
            ));
        },
        nonregisteredEmailInvites() {
            return this.emailInvites.filter(connection => (
                connection.status !== 'accepted' &&
                connection.status !== 'bypassed'
            ));
        },
    },
    methods: {
        fetchSuggestions() {
            axios.get(this.suggestUrl)
                .then(response => response.data)
                .then((jsonResponse) => {
                    this.connections = jsonResponse.connections;
                    this.emailInvites = jsonResponse.emailInvites;
                })
                .then(() => {
                    this.loading = false;
                });
        },
        resetEmailInvite() {
            this.emailInviteAddress = null;
            this.emailInviteModelVisibility = false;
        },
        triggerEmailInvite() {
            if (this.isEmailValid(this.emailInviteAddress)) {
                if (this.buzzConfig.email_invite_popup) {
                    this.emailInviteModelVisibility = true;
                } else {
                    this.$refs.emailInvite.sendEmailInvite();
                }
            }
        },
        isEmailValid(email) {
            // eslint-disable-next-line max-len
            const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

            return re.test(email);
        },
    },
};
</script>
