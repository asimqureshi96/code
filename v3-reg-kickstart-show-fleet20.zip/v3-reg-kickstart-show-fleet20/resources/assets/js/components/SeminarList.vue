<template>
    <div>
        <div 
            class="text-center" 
            v-if="Object.keys(seminars).length > 1">
            <a
                :class="getClass(day)"
                @click="selectedDay = day;"
                href="javascript:;"
                v-for="(seminarsByLocation, day) in seminars"
            >{{ day }}</a
            >
        </div>

        <seminar-schedule
            :direct-booking="directBooking"
            :key="seminarsByLocation.id"
            :seminars="seminarsByLocation"
            :seminar-urls="{
                paid: {
                    hasOverlappingMeeting: paidHasOverlappingMeeting,
                    attachUrl: paidLeadAttachUrl,
                    detachUrl: paidLeadDetachUrl,
                    seminarUrl: paidSeminarUrl,
                },
                free: {
                    hasOverlappingMeeting: hasOverlappingMeeting,
                    attachUrl: leadAttachUrl,
                    detachUrl: leadDetachUrl,
                    seminarUrl: seminarUrl,
                },
            }"
            v-for="(seminarsByLocation, day) in seminars"
            v-show="day === selectedDay"
        />
    </div>
</template>

<script>
import SeminarSchedule from './SeminarSchedule.vue';

export default {
    props: {
        day: {
            type: String,
            default: '',
        },
        directBooking: {
            type: Boolean,
            required: true,
        },
        seminars: {
            type: Object,
            required: true,
        },
        seminarUrl: {
            type: String,
            required: true,
        },
        hasOverlappingMeeting: {
            type: String,
            required: true,
        },
        leadAttachUrl: {
            type: String,
            required: true,
        },
        leadDetachUrl: {
            type: String,
            required: true,
        },
        paidSeminarUrl: {
            type: String,
            required: true,
        },
        paidLeadAttachUrl: {
            type: String,
            required: true,
        },
        paidLeadDetachUrl: {
            type: String,
            required: true,
        },
        paidHasOverlappingMeeting: {
            type: String,
            required: true,
        },
    },
    components: {
        SeminarSchedule,
    },
    data() {
        return {
            selectedDay: null,
        };
    },
    created() {
        this.selectedDay = this.day ? this.day : Object.keys(this.seminars)[0];
    },
    methods: {
        getClass(day) {
            let btnClass = 'btn btn-lg btn-primary mr-1 ml-1';

            if (day === this.selectedDay) {
                btnClass += ' selected-day';
            }

            return btnClass;
        },
    },
};
</script>

<style type="text/css">
.selected-day {
    background-color: #2579a9;
    border-color: #2473a0;
}
</style>
