<template>
    <div>
        <h6
            class="truncate text-center"
            :title="invite.provider_recipient"
        >
            {{ invite.provider_recipient }}
        </h6>

        <img
            :src="invite.customer.avatar"
            class="img-thumbnail img-responsive center-block"
            v-if="invite.customer && invite.customer.avatar"
        >

        <img
            class="img-thumbnail img-responsive center-block"
            src="/images/placeholder-image.jpg"
            v-else
        >
    </div>
</template>

<script>
export default {
    props: [
        'invite',
    ],
};
</script>
