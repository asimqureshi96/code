require('formdata-polyfill');

/* eslint-disable func-names */
window.Buzz = (function() {
    const $document = $(document);

    const handleSwalDefault = () => {
        swal.setDefaults({
            cancelButtonText: Translations.transUi('Cancel'),
            confirmButtonText: Translations.transUi('OK'),
        });
    };

    const handleAjaxForm = require('./handle/ajaxForm.js'); // eslint-disable-line global-require
    const handleWizardButtons = require('./handle/wizzardButtons.js'); // eslint-disable-line global-require

    const isTouchDevice = () => {
        let result = false;

        if (window.PointerEvent && 'maxTouchPoints' in navigator) {
            // if Pointer Events are supported, just check maxTouchPoints
            if (navigator.maxTouchPoints > 0) {
                result = true;
            }
        } else if (window.matchMedia && window.matchMedia('(any-pointer:coarse)').matches) {
            // check for any-pointer:coarse which mostly means touchscreen
            result = true;
        } else if (
            'ontouchstart' in window ||
            (window.DocumentTouch && document instanceof DocumentTouch) ||
            'onmsgesturechange' in window
        ) {
            // last resort - check for exposed touch events API / event handler
            result = true;
        }

        return result;
    };

    const confirm = object => {
        swal({
            title: object.title || Translations.transUi('Are you sure?'),
            text: object.text || Translations.transUi('You are sure you want to proceed?'),
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#bf5329',
            cancelButtonColor: '#636b6f',
            confirmButtonText: Translations.transUi('Confirm'),
        })
            .then(() => {
                object.success();
            })
            .catch(swal.noop);
    };

    const handleConfirm = () => {
        $document.on('click', '[data-buzz-confirm]', function(e) {
            const $el = $(this);
            let $form;

            if ($el.attr('type') === 'submit') {
                $form = $el.closest('form');

                if (!$form[0].checkValidity()) {
                    return;
                }
            }

            e.preventDefault();
            e.stopPropagation();

            confirm({
                text: $el.data('buzz-confirm'),
                success: () => {
                    if ($el.attr('href')) {
                        document.location.href = $el.attr('href');
                    } else if ($el.attr('type') === 'submit') {
                        $form.trigger('submit');
                    }
                },
            });
        });
    };

    // INIT ACTIONS
    if (isTouchDevice()) {
        $('body').addClass('touch');
    }
    // INIT ACTIONS

    return {
        init: $context => {
            if ($context) {
                // Ajax
                //
            } else {
                handleSwalDefault();
                handleAjaxForm();
                handleConfirm();
                //
                handleWizardButtons();
            }
        },
        confirm,
        isTouchDevice,
    };
})();
/* eslint-enable func-names */
