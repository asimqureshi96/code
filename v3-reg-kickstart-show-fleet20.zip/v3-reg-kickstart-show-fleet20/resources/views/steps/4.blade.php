<answer
    :answer="{{ customer()->getAnswerByIdentifier('are-you-involved-in-the-decision-making-process') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['are-you-involved-in-the-decision-making-process'] }}"
    :required="{{ in_array('are-you-involved-in-the-decision-making-process', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('how-many-employees-work-in-your-organisation') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['how-many-employees-work-in-your-organisation'] }}"
    :required="{{ in_array('how-many-employees-work-in-your-organisation', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('is-your-fleet') ?? 'null' }}"
    :question="{{ $questions['is-your-fleet'] }}"
    :required="{{ in_array('is-your-fleet', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('are-you-a-supplier-to-the-fleet-industry') ?? 'null' }}"
    :question="{{ $questions['are-you-a-supplier-to-the-fleet-industry'] }}"
    :required="{{ in_array('are-you-a-supplier-to-the-fleet-industry', $required) ? 'true' : 'false' }}"
></answer>
