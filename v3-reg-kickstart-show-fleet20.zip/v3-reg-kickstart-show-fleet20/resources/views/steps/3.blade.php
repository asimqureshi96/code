<answer
    :answer="{{ customer()->getAnswerByIdentifier('how-many-cars-does-your-company-run-in-its-own-fleet') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['how-many-cars-does-your-company-run-in-its-own-fleet'] }}"
    :required="{{ in_array('how-many-cars-does-your-company-run-in-its-own-fleet', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('how-many-lcvs-does-your-company-run-in-its-own-fleet') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['how-many-lcvs-does-your-company-run-in-its-own-fleet'] }}"
    :required="{{ in_array('how-many-lcvs-does-your-company-run-in-its-own-fleet', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('what-is-your-primary-job-function') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['what-is-your-primary-job-function'] }}"
    :required="{{ in_array('what-is-your-primary-job-function', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('what-is-your-organisations-primary-activity') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['what-is-your-organisations-primary-activity'] }}"
    :required="{{ in_array('what-is-your-organisations-primary-activity', $required) ? 'true' : 'false' }}"
></answer>
