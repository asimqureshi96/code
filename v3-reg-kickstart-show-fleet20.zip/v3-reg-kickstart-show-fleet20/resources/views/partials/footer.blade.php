<div class="container footer-top">
    <div class="row">
        <div class="col-md-2 desktopFooter">
        </div>
        <div class="col-md-2 desktopFooter">
            <h3 class="mt-2 font-header">Venue Details <i class="fa fa-building"></i></h3>
            <h5 class="font-normal">National Exhibition Centre, <br>North Ave, Marston Green, <br>Birmingham <br>B40 1NT
            </h5>
        </div>
        <div class="col-sm-12 text-center mobileFooter">
            <h3 class="mt-2 font-header">Venue Details <i class="fa fa-building"></i></h3>
            <h5 class="font-normal">National Exhibition Centre, <br>North Ave, Marston Green, <br>Birmingham <br>B40 1NT
            </h5>
        </div>
        <div class="col-md-2 desktopFooter">
            <h3 class="mt-2 font-header">Opening Times <i class="fa fa-clock-o"></i></h3>
            <h5 class="font-normal">Tuesday 6th October 2020 <br> 9:30am - 16:30pm</h5>
            <h5 class="font-normal">Wednesday 7th October 2020 <br> 9:30am - 16:00pm</h5>
        </div>
        <div class="col-sm-12 text-center mobileFooter">
            <h3 class="mt-2 font-header">Opening Times <i class="fa fa-clock-o"></i></h3>
            <h5 class="font-normal">Tuesday 6th October 2020 <br> 9:30am - 16:30pm</h5>
            <h5 class="font-normal">Wednesday 7th October 2020 <br> 9:30am - 16:00pm</h5>
        </div>
        <div class="col-md-2 desktopFooter">
            <h3 class="mt-2 font-header">Useful Links <i class="fa fa-link"></i></h3>
            <a
                class="font-normal"
                style="color: white"
                target="_blank"
                href="https://www.bauerlegal.co.uk/website-terms-of-use-2016-03-22"
            ><h5>Terms and Conditions</h5></a>
            <a
                class="font-normal"
                style="color: white"
                target="_blank"
                href="https://www.bauerlegal.co.uk/privacy-policy-20180703"
            ><h5>Privacy Policy</h5></a>
        </div>
        <div class="col-sm-12 text-center mobileFooter">
            <h3 class="mt-2 font-header">Useful Links <i class="fa fa-link"></i></h3>
            <a
                class="font-normal"
                style="color: white"
                target="_blank"
                href="https://www.bauerlegal.co.uk/website-terms-of-use-2016-03-22"
            ><h5>Terms and Conditions</h5></a>
            <a
                class="font-normal"
                style="color: white"
                target="_blank"
                href="https://www.bauerlegal.co.uk/privacy-policy-20180703"
            ><h5>Privacy Policy</h5></a>
        </div>
        <div class="col-md-2 desktopFooter">
            <h3 class="mt-2 font-header">Social Links <i class="fa fa-hashtag"></i></h3>
            <div class="text-left">
                <ul style="list-style: none; padding: 0;">

                    <a
                        class="font-normal"
                        style="color: white"
                        href="https://twitter.com/fleetlive"
                        target="_blank"
                    >
                        <li>Twitter <i class="fa fa-twitter-square"></i></li>
                    </a>
                    <a
                        class="font-normal"
                        style="color: white"
                        href="https://www.linkedin.com/company/fleet-live/"
                        target="_blank"
                    >
                        <li>LinkedIn <i class="fa fa-linkedin-square"></i></li>
                    </a>
                </ul>
            </div>
        </div>

        <div class="col-sm-12 mb-3 mobileFooter text-center">
            <h3 class="mt-2 font-header">Social Links <i class="fa fa-hashtag"></i></h3>
            <a
                class="font-normal"
                style="color: white"
                href="https://twitter.com/fleetlive"
                target="_blank"
            >
                <i class="fa fa-twitter-square fa-2x"></i>
            </a>
            <a
                class="ml-2 font-normal"
                style="color: white"
                href="https://www.linkedin.com/company/fleet-live/"
                target="_blank"
            >
                <i class="fa fa-linkedin-square fa-2x"></i>
            </a>
        </div>
        <div class="col-md-2 desktopFooter">
        </div>
    </div>
</div>
<footer>
    <div class="row">

        <div class="col-md-4 desktopFooter"></div>
        <div class="col-md-4 text-center">
            <p style="color: black">
                Powered by
                <a
                    href="https://www.livebuzz.co.uk"
                    target="_blank"
                >
                    <img
                        src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/ocean-media/campaign/818ea3be-4359-11ea-977d-000000000000/livebuzz-black.png"
                        alt="LiveBuzz Logo"
                    >
                </a>
            </p>
        </div>
        <div class="col-md-4 text-right desktopFooter">

            <div class="text-right">
                <p style="color: black; float: right;">
                    © 2020 Bauer Consumer Media Ltd<br>
                    Media House, Lynch Wood, Peterborough, PE2 6EA
                </p>
            </div>
        </div>
        <div class="col-md-4 text-center mobileFooter">

            <p style="color: black;">© 2020 Bauer Consumer Media Ltd<br>
                Media House, Lynch Wood,<br> Peterborough, PE2 6EA
            </p>
            <img
                style="width: 31px; height:31px;"
                class="mr-2 mt-2"
                src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/bauermedia/campaign/db7df70e-5d39-11ea-84c1-000000000000/bauer%20%281%29.png"
            >

        </div>

    </div>
</footer>
