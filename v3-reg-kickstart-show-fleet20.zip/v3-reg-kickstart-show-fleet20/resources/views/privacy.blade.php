@extends('layout/auth')

@section('content')
    <div class="grey-section border-top-0 mb-3">
        <h3>{{ transUi('Communication Preferences') }}</h3>
        <p class="mb-0">{{ transUi('Update your preferences below') }}</p>
    </div>

    <form
        role="form"
        method="post"
        action="{{ route('save-privacy') }}"
    >

        <answer
            :answer="{{ customer()->getAnswerByIdentifier('do-you-wish-to-receive-fleet-news-magazine-in-printdigital-format') ?? 'null' }}"
            :column-count="2"
            :question="{{ $questions['do-you-wish-to-receive-fleet-news-magazine-in-printdigital-format'] }}"
            :required="{{ in_array('do-you-wish-to-receive-fleet-news-magazine-in-printdigital-format', $required) ? 'true' : 'false' }}"
        ></answer>
        <h5>Registering for this event activates your Fleet News membership. Fleet News (published by Bauer) will contact you about your membership. 
            We will also contact you with details of other offers
            and information relating to our products and services, some of which we can only send by email. 
            We do not want you to miss out on additional industry information, but if you would prefer NOT to receive these, please tick here.</h5>
        <answer
            :answer="{{ customer()->getAnswerByIdentifier('fleet-news-membership') ?? 'null' }}"
            :column-count="2"
            :question="{{ $questions['fleet-news-membership'] }}"
            :required="{{ in_array('fleet-news-membership', $required) ? 'true' : 'false' }}"
            :show-title="false"
        ></answer>
        <h5>Terms & Conditions</h5>
        <buzz-checkbox
            name="questions[terms-and-conditions][options][i-agree][key]"
            :required="{{ in_array('terms-and-conditions', $required) ? 'true' : 'false' }}"
            true-value="b1c1e7b2-68fc-11ea-ab71-000000000000"
            :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('terms-and-conditions') ? ['b1c1e7b2-68fc-11ea-ab71-000000000000'] : [])}}"
        >
    <span class="required">
        I have read and understood the <a href="https://www.bauerlegal.co.uk/website-terms-of-use-2016-03-22" target="_blank">Terms & Conditions</a>
    </span>
        </buzz-checkbox>
        <h5>Privacy Policy</h5>


        <buzz-checkbox
            name="questions[privacy-policy][options][i-agreec][key]"
            :required="{{ in_array('privacy-policy', $required) ? 'true' : 'false' }}"
            true-value="71264c92-68fd-11ea-9561-000000000000"
            :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('privacy-policy') ? ['71264c92-68fd-11ea-9561-000000000000'] : [])}}"
        >
    <span class="required">
        I have read and understood the <a href="https://www.bauerlegal.co.uk/privacy-policy-20180703" target="_blank">Privacy Policy</a>
    </span>
        </buzz-checkbox>



        <button
            type="submit"
            class="btn btn-primary btn-block mt-4"
        >
            {{ transUi('Submit') }}
        </button>
    </form>
@endsection
