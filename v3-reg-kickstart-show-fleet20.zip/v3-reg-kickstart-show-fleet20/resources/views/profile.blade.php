@extends('layout/auth')

@section('content')
    <div class="grey-section border-top-0 mb-3 desktopText">
        <h3>{{ transUi('Summary') }}</h3>
        <p class="mb-0">{{ transUi('Review your registration details') }}</p>
    </div>
    <div class="grey-section border-top-0 mb-3 mobileText text-center">
        <h3>{{ transUi('Summary') }}</h3>
        <p class="mb-0">{{ transUi('Review your registration details') }}</p>
    </div>
    <div class="row justify-content-between">
        <div class="col-xl-6">
            <h3 class="mb-3 desktopText">{{ transUi('Your badge') }} <i class="fa fa-id-badge"></i></h3>
            <h3 class="mb-3 mobileText text-center">{{ transUi('Your badge') }} <i class="fa fa-id-badge"></i></h3>

            @if(customer()->status === 'active')
                <p class="mb-0 desktopText">
                    Congratulations, you're registered to attend Fleet & Mobility Live 2020! <br>
                    We are pleased to inform you that your registration has been successful.<br>
                    You will receive a Email confirmation in due course.
                </p>
                <p class="mb-0 mobileText text-center">
                    Congratulations, you're registered to attend Fleet & Mobility Live 2020! <br>
                    We are pleased to inform you that your registration has been successful.<br>
                    You will receive a Email confirmation in due course.
                </p>
            @elseif(customer()->status === 'pending')
                <p class="mb-0 desktopText">
                    Thank you for registering for Fleet LIVE 2020.<br>

                    Your registration will now go into our approval system.<br>

                    Please note that the approval process can take up to 10 working days.<br>

                    You will receive further information via Email in due course, thank you for your interest in Fleet LIVE.
                </p>
                <p class="mb-0 mobileText text-center">
                    Thank you for registering for Fleet LIVE 2020.<br>

                    Your registration will now go into our approval system.<br>

                    Please note that the approval process can take up to 10 working days.<br>

                    You will receive further information via Email in due course, thank you for your interest in Fleet LIVE.
                </p>
            @endif

            <h4 class="mt-5 mb-3 desktopText">{{ transUi('Registration Details') }} <i class="fa fa-info-circle"></i>
            </h4>
            <h4 class="mt-5 mb-3 text-center mobileText">{{ transUi('Registration Details') }}
                <i class="fa fa-info-circle"></i></h4>
            <div class="desktopText">
                <p class="mb-1">{{ customer()->title }} {{ customer()->name }}</p>
                <p class="mb-1">{{ customer()->email }}</p>
                <p class="mb-1">{{ customer()->job_title }}</p>
                <p class="mb-1">{{ customer()->company }}</p>
            </div>
            <div class="mobileText text-center">
                <p class="mb-1">{{ customer()->title }} {{ customer()->name }}</p>
                <p class="mb-1">{{ customer()->email }}</p>
                <p class="mb-1">{{ customer()->job_title }}</p>
                <p class="mb-1">{{ customer()->company }}</p>
            </div>

            <div class="mt-3">
                <div class="row">
                    <div class="col-md-6  mb-2 desktopText">
                        <a
                            href="{{ route('step1') }}"
                            class="btn btn-sm btn-secondary"
                        >
                            <i
                                class="fa fa-pencil"
                                aria-hidden="true"
                            ></i>
                            {{ transUi('Amend my registration') }}
                        </a>
                    </div>

                    <div class="col-md-6 mb-2 mobileText text-center">
                        <a
                            href="{{ route('step1') }}"
                            class="btn btn-sm btn-secondary"
                        >
                            <i
                                class="fa fa-pencil"
                                aria-hidden="true"
                            ></i>
                            {{ transUi('Amend my registration') }}
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <h3 class="mb-3 mt-2 desktopText">{{ transUi('Venue Details') }} <i class="fa fa-building"></i></h3>
            <h3 class="mb-3 mt-2 mobileText text-center">{{ transUi('Venue Details') }} <i class="fa fa-building"></i>
            </h3>
            <div class="desktopText">
                <h5 class="mb-2">
                    {{ trans('buzz.event.date') }}
                    {{ trans('buzz.event.venue') }}
                </h5>

                <address class="mb-2 my-1">
                    National Exhibition Centre, Marston
                    Green, Birmingham B40 1NT
                </address>
            </div>
            <div class="mobileText text-center">
                <h5 class="mb-2">
                    {{ trans('buzz.event.date') }}
                    {{ trans('buzz.event.venue') }}
                </h5>

                <address class="mb-2 my-1">
                    National Exhibition Center, Marston
                    Green, Birmingham B40 1NT
                </address>
            </div>
            <p class="mb-4">
                <a
                    href="http://www.thenec.co.uk/"
                    target="_blank"
                >
                    <i
                        class="fa fa-globe"
                        aria-hidden="true"
                    ></i>
                    Visit Website
                </a>

                <a
                    href="https://www.google.co.uk/maps/dir/My+location/NEC,+National+Exhibition+Center,+Halls,+Marston+Green,+Birmingham+B40+1NT"
                    target="_blank"
                >
                    <i
                        class="ml-2 fa fa-map-marker"
                        aria-hidden="true"
                    ></i>
                    Get directions
                </a>
            </p>
            <leaflet-map
                :lat="52.4548971"
                :lng="-1.7184944"
                :zoom="13"
            ></leaflet-map>


        </div>
    </div>

    @if(config('buzz.organization') === 'reedexpo')
        <rx-recommendations
            recommendations-url="{{ route('rx-recommendations::fetch') }}"
        ></rx-recommendations>
    @endif

    @if($seminars->count())
        <h3 class="mb-3">{{ transUi('Seminar Agenda') }}</h3>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">{{ transUi('Session') }}</th>
                    <th scope="col">{{ transUi('Date & Time') }}</th>
                    <th scope="col">{{ transUi('Theatre') }}</th>
                    <th scope="col">
                        <div class="row justify-content-between">
                            <div class="col-md-8">{{ transUi('Attendee(s)') }}</div>
                            <div class="col-md-4">{{ transUi('Status') }}</div>
                        </div>
                    </th>
                </tr>
            </thead>
            <tbody>
                @foreach($seminars as $seminar)
                    <tr>
                        <td>{{ $seminar->title }}</td>
                        <td>
                            {{ $seminar->starts_at->copy()->tz(cache('settings')['locale']['timezone'])->format('l jS M') }}
                            <br/>
                            {{ $seminar->starts_at->copy()->tz(cache('settings')['locale']['timezone'])->format('H:i') }} - {{ $seminar->ends_at->copy()->tz(cache('settings')['locale']['timezone'])->format('H:i') }}
                        </td>
                        <td>{{ $seminar->theater->name }}</td>
                        <td>
                            @foreach($seminar->attendees_filtered as $attendee)
                                <div class="row justify-content-between">
                                    <div class="col-md-8">
                                        @if($attendee->customer)
                                            @if($attendee->customer->id === customer()->id)
                                                <i
                                                    title="{{ transUi('I am attending') }}"
                                                    class="fa fa-user"
                                                ></i>
                                            @else
                                                {{ $attendee->customer->name }}
                                            @endif
                                        @else
                                            {{ transUi('non allocated') }}
                                        @endif
                                    </div>
                                    <div class="col-md-4">
                                        @if($attendee->status === 'in_basket')
                                            {{ transUi('In Basket') }}
                                        @elseif($attendee->status === 'awaiting_payment')
                                            {{ transUi(' Awaiting Payment') }}
                                        @else
                                            {{ transUi('Confirmed') }}
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif

    @if($webModulesOauthToken)
        <web-module-loader
            organization="{{ config('buzz.organization') }}"
            campaign="{{ config('buzz.campaign') }}"
            web-module-o-auth-token="{{ $webModulesOauthToken }}"
            version="v1-latest-{{ app()->environment() === 'production' ? 'prod' : 'staging' }}"
            env="production"
        ></web-module-loader>
    @endif
    @if(customer()->status === 'active')

        @if(config('buzz.social_reg_enabled') || config('buzz.social_share_enabled') || config('buzz.social_invite_enabled'))

            <div class="grey-section fit-to-bottom mt-3">
                @if(config('buzz.social_share_enabled'))
                    <div class="row justify-content-center mb-3">
                        <div class="col-md-6">

                            <h5 class="mt-4 text-center">{{ transUi('Tell people you\'re coming') }}</h5>

                            <div class="row social-icons pb-2">
                                <div class="col-4 facebook-icon">
                                    <a
                                        href="http://www.facebook.com/share.php?u={{ urlencode($shareUrls['facebook']) }}"
                                        target="_blank"
                                    >
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </div>
                                <div class="col-4 twitter-icon">
                                    <a
                                        href="http://twitter.com/intent/tweet?status={{ urlencode(trans('buzz.twitter_share_message')) }}+{{ urlencode($shareUrls['twitter']) }}"
                                        target="_blank"
                                    >
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </div>
                                <div class="col-4 linkedin-icon">
                                    <a
                                        href="http://www.linkedin.com/shareArticle?mini=true&url={{ urlencode($shareUrls['linkedin']) }}&summary={{ urlencode(trans('buzz.linkedin_share_message')) }}"
                                        target="_blank"
                                    >
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                @if(config('buzz.social_invite_enabled'))
                    <social
                        :buzz-config="{{ json_encode(config('buzz')) }}"
                        suggest-url="{{ route('social::suggest') }}"
                        invite-connection-url="{{ route('social::invite-connection') }}"
                        invite-email-url="{{ route('social::invite-email') }}"
                    ></social>
                @endif

                @if(config('buzz.social_reg_enabled'))
                    <div class="login-buttons login-buttons--main">
                        <h5 class="mt-4 text-center">{{ transUi('Connect your social accounts') }}</h5>
                        @foreach([
                            'linkedin' => 'linkedin',
                            'facebook' => 'facebook',
                            'twitter' => 'twitter',
                         ] as $icon => $provider)
                            @if($customerSocials->contains($provider))
                                <span class="btn btn--buzz btn--{{ $provider }} connected">
                            <i class="fa fa-{{ $icon }}"></i> {{ transUi('already connected') }}
                        </span>
                            @else
                                <a
                                    class="btn btn--buzz btn--{{ $provider }}"
                                    href="{{ $stream->social_connect_urls[$provider] .'/' . customer()->id  }}"
                                >
                                    <i class="fa fa-{{ $icon }}"></i> {{ transUi('Connect') }}
                                </a>
                            @endif
                        @endforeach
                        @endif
                    </div>
                @endif
            </div>
        @endif
@endsection
