<?php

// Steps
Route::group(['prefix' => 'step', 'namespace' => 'Step'], function () {
    for ($step = 1; $step <= config('buzz.steps'); $step++) {
        $middlewares = ["step:{$step}"];

        if ($step > 1) {
            $middlewares[] = 'auth';
        }

        Route::get($step, "Step{$step}Controller@render")->name("step{$step}")->middleware($middlewares);
        Route::post($step, "Step{$step}Controller@save")->name("step{$step}")->middleware($middlewares);
    }
});
