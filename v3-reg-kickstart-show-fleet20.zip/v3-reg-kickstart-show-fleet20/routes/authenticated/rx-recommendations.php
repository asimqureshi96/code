<?php

Route::group(['prefix' => 'rx-recommendations', 'as' => 'rx-recommendations::'], function () {
    Route::get('fetch', 'RxRecommendationsController@fetch')->name('fetch');
});
