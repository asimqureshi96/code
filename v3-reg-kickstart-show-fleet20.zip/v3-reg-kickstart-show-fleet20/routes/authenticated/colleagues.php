<?php

if (!config('buzz.register_customer_enabled')) {
    return;
}

Route::get('colleagues', 'ColleagueController@index')->name('colleagues');
Route::get('colleague/{colleague_id?}', 'ColleagueController@render')->name('register-customer');
Route::post('colleague/{colleague_id?}', 'ColleagueController@save')->name('register-customer');
Route::get('colleague/{colleague_id}/delete', 'ColleagueController@delete')->name('register-customer-delete');
