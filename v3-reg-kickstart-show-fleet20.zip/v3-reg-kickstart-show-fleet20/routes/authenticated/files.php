<?php

Route::group(['prefix' => 'files', 'as' => 'files::'], function () {
    Route::get('delete/{identifier}', 'FilesController@delete')->name('delete');
});
