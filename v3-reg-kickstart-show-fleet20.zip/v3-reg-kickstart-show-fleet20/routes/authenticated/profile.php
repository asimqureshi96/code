<?php

Route::group(['prefix' => 'profile'], function () {
    Route::get('/', 'ProfileController@render')->name('profile');
});

Route::get('/thankyou', 'ProfileController@render')->name('thanks');

Route::get('privacy', 'ProfileController@renderPrivacy')->name('privacy');
Route::post('save-privacy', 'ProfileController@savePrivacy')->name('save-privacy');
