<?php

namespace App\Providers;

use App;
use Buzz\Helpers\Exceptions\Fatal;
use Buzz\Control\Campaign\Stream;
use Illuminate\Support\ServiceProvider;

class SettingsServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     * @throws Fatal
     */
    public function boot()
    {
        if (!app()->runningInConsole() && !$this->app->isDownForMaintenance()) {
            $this->app->singleton(Stream::class, function () {
                return (new Stream())->expand(['systemFiles'])->find(config('buzz.stream'));
            });

            $stream = app(Stream::class);

            if (!$stream) {
                throw new Fatal(sprintf('Stream %1$s does not exist!', config('buzz.stream')));
            }

            if ($stream->audience !== 'visitor') {
                throw new Fatal('Stream is not a visitor one!');
            }

            view()->share('stream', $stream);
            view()->share('theme', $stream->theme);
        }
    }
}
