<?php

namespace App\Http\Controllers;

use App\Http\Traits\Flow;
use App\Http\Traits\SeminarLocal;
use RegCore\Http\Controllers as Core;

class SeminarController extends Core\SeminarController
{
    use Flow;
    use SeminarLocal;
}
