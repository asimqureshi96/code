<?php

namespace App\Http\Controllers;

use App\Http\Traits\Flow;
use RegCore\Http\Controllers as Core;

class SocialController extends Core\SocialController
{
    use Flow;
}
