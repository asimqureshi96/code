<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step4Controller extends Step\Step4Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 4;

    // required to be answered, open question can be submitted empty
    protected function getRequired()
    {
        return [
            'are-you-involved-in-the-decision-making-process',
            'how-many-employees-work-in-your-organisation',
            'is-your-fleet',
            'are-you-a-supplier-to-the-fleet-industry',
        ];
    }

    protected function getQuestions()
    {
        return [
            'are-you-involved-in-the-decision-making-process',
            'how-many-employees-work-in-your-organisation',
            'is-your-fleet',
            'are-you-a-supplier-to-the-fleet-industry',
        ];
    }

    /**
     * @param QuestionHelper $questionHelper
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Buzz\Helpers\Exceptions\Error
     */
    public function render(QuestionHelper $questionHelper)
    {
        $questions = $questionHelper->getByIdentifiers($this->getQuestions());

        $required = $this->getRequired();

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {
        $this->handleFlow();

        $required = $this->getRequired();

        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        return $this->next();
    }
}

