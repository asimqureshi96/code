<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step3Controller extends Step\Step3Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 3;

    // required to be answered, open question can be submitted empty
    protected function getRequired()
    {
        return [
            'how-many-cars-does-your-company-run-in-its-own-fleet',
            'how-many-lcvs-does-your-company-run-in-its-own-fleet',
            'what-is-your-primary-job-function',
            'what-is-your-organisations-primary-activity',
            ];
    }

    protected function getQuestions()
    {
        return [
            'how-many-cars-does-your-company-run-in-its-own-fleet',
            'how-many-lcvs-does-your-company-run-in-its-own-fleet',
            'what-is-your-primary-job-function',
            'what-is-your-organisations-primary-activity',
        ];
    }

    /**
     * @param QuestionHelper $questionHelper
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Buzz\Helpers\Exceptions\Error
     */
    public function render(QuestionHelper $questionHelper)
    {
        $questions = $questionHelper->getByIdentifiers($this->getQuestions());

        $required = $this->getRequired();

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {
        $this->handleFlow();

        $required = $this->getRequired();

        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        return $this->next();
    }
}
