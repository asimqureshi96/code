<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step5Controller extends Step\Step5Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 5;

    // required to be answered, open question can be submitted empty
    protected function getRequired()
    {
        return [
            'do-you-wish-to-receive-fleet-news-magazine-in-printdigital-format',
            'what-reasons-do-you-attend-fleet-live-tick-all-that-apply',
            'privacy-policy',
            'terms-and-conditions',
        ];
    }

    protected function getQuestions()
    {
        return [
            'do-you-wish-to-receive-fleet-news-magazine-in-printdigital-format',
            'what-reasons-do-you-attend-fleet-live-tick-all-that-apply',
            'privacy-policy',
            'terms-and-conditions',
            'fleet-news-membership',
        ];
    }

    /**
     * @param QuestionHelper $questionHelper
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Buzz\Helpers\Exceptions\Error
     */
    public function render(QuestionHelper $questionHelper)
    {
        $questions = $questionHelper->getByIdentifiers($this->getQuestions());

        $required = $this->getRequired();

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {
        $this->handleFlow();

        $required = $this->getRequired();

        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        return $this->complete();
    }
}


