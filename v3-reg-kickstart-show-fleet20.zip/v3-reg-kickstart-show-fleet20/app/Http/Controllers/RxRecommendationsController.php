<?php

namespace App\Http\Controllers;

use RegCore\Http\Controllers as Core;

class RxRecommendationsController extends Core\RxRecommendationsController
{
}
