<?php

namespace App\Http\Middleware;

use RegCore\Http\Middleware;

class Affiliate extends Middleware\Affiliate
{
}
