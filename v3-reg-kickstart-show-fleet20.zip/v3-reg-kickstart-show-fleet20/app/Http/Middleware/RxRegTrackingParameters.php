<?php

namespace App\Http\Middleware;

use RegCore\Http\Middleware;

class RxRegTrackingParameters extends Middleware\RxRegTrackingParameters
{
}
