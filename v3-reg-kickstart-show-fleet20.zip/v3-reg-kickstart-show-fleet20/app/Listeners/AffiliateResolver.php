<?php

namespace App\Listeners;

use RegCore\Listeners;

class AffiliateResolver extends Listeners\AffiliateResolver
{
}
