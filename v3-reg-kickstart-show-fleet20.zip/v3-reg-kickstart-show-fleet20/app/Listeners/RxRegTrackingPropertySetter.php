<?php

namespace App\Listeners;

use RegCore\Listeners;

class RxRegTrackingPropertySetter extends Listeners\RxRegTrackingPropertySetter
{
}
