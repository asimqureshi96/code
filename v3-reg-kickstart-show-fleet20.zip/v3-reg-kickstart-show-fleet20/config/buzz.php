<?php

return [
    //===================
    //====== Flags ======
    //===================

    /*
     * Toggles order and basket related sections
     */
    'paid_show'                 => false,

    /*
     * Onsite mode
     */
    'onsite'                    => false,

    /*
     * Social Reg settings
     */
    'social_reg_enabled'        => true,
    'social_invite_enabled'     => true,
    'email_invite_popup'        => true,
    'social_share_enabled'      => true,

    /*
     * Affiliates
     */
    'affiliates_enabled'        => true,

    /*
     * Invites
     */
    'invites_enabled'           => true,

    /*
     * Register colleague
     */
    'register_customer_enabled' => false,

    /*
     * Password required
     */
    'password_required'         => true,

    /*
     * Meeting module enabled
     */
    'meetings_tool_enabled'     => false,


    //========================
    //====== Parameters ======
    //========================

    'steps'                      => 5,

    /*
     * LiveControl API
     */
    'api_key'                    => env('CONTROL_API_KEY'),
    'api_domain'                 => env('CONTROL_API_DOMAIN'),
    'api_protocol'               => env('CONTROL_API_PROTOCOL'),
    'api_proxy'                  => env('CONTROL_API_PROXY'),

    /*
     * Signed URL Login
     */
    'signed_url_secret'          => env('SIGNED_URL_SECRET'),

    /*
     * Form Configuration
     */
    'gateway'                    => 'www',
    'organization'               => 'bauermedia',
    'channel'                    => 'fleet-and-mobility-live',
    'campaign'                   => 'fleet-and-mobility-live-2020',
    'stream'                     => 'visitor',
    'branch'                     => 'master',
    'web_module_meetings'        => false,

    /*
     * Marketing campaigns
     */
    'google_analytics'           => '',
    'google_maps_key'            => 'AIzaSyBBH30igm9FKNTTUtYCjIrPq5LiDnkgHsY',

    /*
     * Emails
     */
    'email_invite_template'      => "invite-visitor-to-visitor",

    //========================
    //======= Modules ========
    //========================

    /*
     * Seminars
     */
    'seminars_enabled'           => false,
    // How many minutes of overlap is allowed for start and end times
    'seminars_overlap'           => 5,
    // allow attaching/detaching seminar to customer
    // seminars_colleague_enabled or seminars_direct_booking can be true at once
    'seminars_colleague_enabled' => false,
    // blocks seminar overview page and attaching detaching happens by clicking on seminar card
    'seminars_direct_booking'    => false,

    /*
     * Customer Clone settings
     */
    'pre_pop_copy_demos'         => false,
    'pre_pop_include_demos'      => [],
    'one_click_copy_demos'       => false,
    'one_click_exclude_demos'    => ['abc', 'audit'],
    'one_click_badge_type'       => 'visitor',
];
