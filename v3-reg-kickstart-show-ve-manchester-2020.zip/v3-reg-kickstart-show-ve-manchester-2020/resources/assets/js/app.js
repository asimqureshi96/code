// Build icon assets -> required to fix https://github.com/KoRiGaN/Vue2Leaflet/issues/28
import { Icon } from 'leaflet';

// eslint-disable-next-line
delete Icon.Default.prototype._getIconUrl;

Icon.Default.mergeOptions({
    // eslint-disable-next-line
    iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
    // eslint-disable-next-line
    iconUrl: require('leaflet/dist/images/marker-icon.png'),
    // eslint-disable-next-line
    shadowUrl: require('leaflet/dist/images/marker-shadow.png')
});

require('v3-assets');

Translations.setTranslations(require('./translations.json'));

window.axios.defaults.headers.common = {
    'X-CSRF-TOKEN': window.csrfToken,
    'X-Requested-With': 'XMLHttpRequest',
};

Vue.component('add-to-basket', require('./components/AddToBasket.vue'));
Vue.component('file-upload', require('./components/FileUpload.vue'));
Vue.component('leaflet-map', require('./components/LeafletMap.vue'));
Vue.component('seminar-booking', require('./components/SeminarBooking.vue'));
Vue.component('seminar-list', require('./components/SeminarList.vue'));
Vue.component('social', require('./components/Social.vue'));
Vue.component('suggest-exhibitors', require('./components/SuggestExhibitors.vue'));

// @todo remove file after buzz-ui integrated
Vue.component('buzz-textarea', require('./components/Buzz/Textarea.vue'));
Vue.component('custom-answer', require('./components/Answer/Answer.vue'));
