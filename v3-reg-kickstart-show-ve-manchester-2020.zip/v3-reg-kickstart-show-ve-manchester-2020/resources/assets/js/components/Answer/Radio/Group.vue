<template>
    <div>
        <h5
            @click="collapsed = !collapsed"
            style="cursor: pointer"
        >
            <i
                class="fa fa-plus-circle"
                v-if="collapsed"
            />
            <i
                class="fa fa-minus-circle"
                v-else
            />
            {{ element.translation.name }}
        </h5>

        <div
            class="pl-4"
            v-show="!collapsed"
        >
            <slot/>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        context: {
            type: Object,
            required: true,
        },
        collapsed: {
            type: Boolean,
            default: true,
        },
        element: {
            type: Object,
            required: true,
        },
    },
    data() {
        return {
            show: !this.collapsed,
        };
    },
    created() {
        if(this.collapsed) {
            this.show = _.some(this.element.elements, this.context.isSelected);
        }
    },
};
</script>
