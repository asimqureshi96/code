<template>
    <div class="cd-schedule">
        <div 
            class="cd-schedule-desktop" 
            :style="getHeight()">
            <div class="timeline">
                <ul>
                    <li v-for="time in timeline">
                        <span>{{ time }}</span>
                    </li>
                </ul>
            </div>
            <!-- .timeline -->
            <div class="events">
                <ul>
                    <li
                        :class="
                            'events-group column-count-' + Object.keys(seminarsByLocation).length
                        "
                        v-for="(seminarList, location) in seminarsByLocation"
                    >
                        <div class="event-location">
                            <span>{{ location }}</span>
                        </div>

                        <ul :class="'timeline-count-' + timeline.length">
                            <li
                                :class="'event-card'"
                                :style="getStyle(seminar)"
                                v-for="seminar in seminarList"
                            >
                                <seminar-booking
                                    :direct-booking="directBooking"
                                    :seminar-urls="seminarUrls"
                                    :seminar="seminar"
                                >
                                    <seminar 
                                        :seminar="seminar" 
                                        :mobile="false" />
                                </seminar-booking>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <!-- .cd-schedule -->
        <div class="cd-schedule-mobile">
            <template v-for="(seminarList, location) in seminarsByLocation">
                <h4 class="event-location">{{ location }}</h4>

                <ul>
                    <li
                        :class="'event-card'"
                        :style="getStyle(seminar, 'mobile')"
                        v-for="seminar in seminarList"
                    >
                        <seminar-booking
                            :direct-booking="directBooking"
                            :seminar-urls="seminarUrls"
                            :seminar="seminar"
                        >
                            <seminar 
                                :seminar="seminar" 
                                :mobile="true" />
                        </seminar-booking>
                    </li>
                </ul>
            </template>
        </div>
        <!-- .cd-schedule-mobile -->
    </div>
</template>

<script>
import Seminar from './Seminar.vue';

export default {
    props: {
        seminars: {
            type: Object,
            required: true,
        },
        seminarUrls: {
            type: Object,
            required: true,
        },
        directBooking: {
            type: Boolean,
            required: true,
        },
    },
    components: {
        Seminar,
    },
    data() {
        return {
            startTime: null,
            endTime: null,
            endMinutes: 0,
            timelineIcrement: 1,
            timeline: [],
            seminarsByLocation: null,
            // schedule style variables
            scheduleRowHeight: 50,
        };
    },
    created() {
        this.seminarsByLocation = this.seminars;
        this.calculateTimelineRange();
        this.calculatetimelineIcrement();
        this.calculateTimeline();
    },
    methods: {
        calculateTimelineRange() {
            const vm = this;

            $.each(this.seminarsByLocation, (location, seminars) => {
                $.each(seminars, (index, $seminar) => {
                    vm.seminarsByLocation[location][index].starts_at = moment(
                        $seminar.starts_at,
                    ).utc();
                    vm.seminarsByLocation[location][index].ends_at = moment($seminar.ends_at).utc();

                    vm.seminarsByLocation[location][index].startInMinutes = moment
                        .duration({
                            minutes: $seminar.starts_at.minutes(),
                            hours: $seminar.starts_at.hours(),
                        })
                        .asMinutes();

                    vm.seminarsByLocation[location][index].endInMinutes = moment
                        .duration({
                            minutes: $seminar.ends_at.minutes(),
                            hours: $seminar.ends_at.hours(),
                        })
                        .asMinutes();

                    if (!vm.startTime || vm.startTime.diff($seminar.starts_at) > 0) {
                        vm.startTime = $seminar.starts_at;
                    }

                    if (!vm.endTime || vm.endTime.diff($seminar.ends_at) < 0) {
                        vm.endTime = $seminar.ends_at;
                    }
                });
            });
        },
        calculatetimelineIcrement() {
            const dayLegth = this.endTime.diff(this.startTime, 'hours');

            if (dayLegth > 10) {
                this.timelineIcrement = 60;
            } else if (dayLegth > 6) {
                this.timelineIcrement = 30;
            } else if (dayLegth > 4) {
                this.timelineIcrement = 15;
            } else {
                this.timelineIcrement = 10;
            }
        },
        calculateTimeline() {
            const currentTime = this.startTime.clone();

            currentTime.minutes(0);

            // get earliest start time while using increments
            while (this.startTime.diff(currentTime, 'minutes') >= this.timelineIcrement) {
                currentTime.add(this.timelineIcrement, 'minutes');
            }

            this.startTime = currentTime.clone();

            this.timeline.push(currentTime.format('H:mm'));

            while (this.endTime.diff(currentTime, 'minutes') >= this.timelineIcrement) {
                currentTime.add(this.timelineIcrement, 'minutes');
                this.timeline.push(currentTime.format('H:mm'));
            }
        },
        getStyle(seminar, mobile) {
            if (mobile !== undefined) {
                return {
                    borderLeftColor: seminar.colour,
                };
            }

            const timelineStart = moment
                .duration({
                    minutes: this.startTime.minutes(),
                    hours: this.startTime.hours(),
                })
                .asMinutes();

            // place each event in the grid -> need to set top position and height
            const duration = seminar.endInMinutes - seminar.startInMinutes;

            let eventTop =
                this.scheduleRowHeight *
                ((seminar.startInMinutes - timelineStart) / this.timelineIcrement);
            let eventHeight = this.scheduleRowHeight * (duration / this.timelineIcrement);

            // prevent overlapping timeline borders
            if (eventTop < 2) {
                eventTop = 2;
                eventHeight -= 2;
            }

            const styles = {
                top: `${eventTop + 3}px`,
                minHeight: `${eventHeight - 8}px`,
                maxHeight: `${eventHeight - 8}px`,
                borderLeftColor: seminar.colour,
            };

            return styles;
        },
        getHeight() {
            return {
                height: `${(this.timeline.length + 1) * this.scheduleRowHeight}px`,
            };
        },
    },
};
</script>
