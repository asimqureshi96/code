<?php

return [

    /*
    |-------------f-------------------------------------------------------------
    | Buzz config translations
    |--------------------------------------------------------------------------
     */

    'event'                     => [
        'name'  => 'VE Manchester',
        'year'  => '2020',
        'date'  => '29th September',
        'venue' => 'Manchester central , Manchester',
    ],

    'meta_description'          => "Register now for Venues + Events Live Manchester 2020!",

    // Email invite
    'email_invite_subject'      => "Join me at Venues + Events Live Manchester 2020!",
    'email_invite_message'      => "I'm going to Venues + Events Live Manchester 2020!. Join me at the innovative and interactive annual exhibition. With some of the industry’s best exhibitors and a variety of features including exciting sessions and hands-on masterclasses.",

    // Linkedin invite
    'connection_invite_subject' => "Join me at Venues + Events Live Manchester 2020!",
    'connection_invite_message' => "I’ve just registered for #VELive! Who’s coming? @VandELive.\n\nhttps://kickstart-visitor.localhost/?invite=INVITE_CODE",
    'linkedin_share_message'    => 'I’ve just registered for #VELive! Who’s coming? @VandELive.',

    // Twitter invite
    'twitter_share_message'     => 'I’ve just registered for #VELive! Who’s coming? @VandELive.',

];
