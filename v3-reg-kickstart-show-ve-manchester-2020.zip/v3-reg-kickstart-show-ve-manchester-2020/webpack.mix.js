const { mix } = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

mix.autoload({
    jquery: ['$', 'window.jQuery', 'jQuery'],
    'popper.js/dist/umd/popper.js': ['Popper'],
});

mix.options({
    postCss: [
        require('autoprefixer')({
            browsers: ['> 1%', 'last 2 versions', 'ie 11'],
        }),
    ],
});

mix
    .js('resources/assets/js/app.js', 'public/js')
    .js('resources/assets/js/buzz.js', 'public/js')
    .sass('resources/assets/sass/app.scss', 'public/css')
    .extract(['vue', 'jquery', 'lodash', 'bootstrap', 'axios', 'moment', 'popper.js'])
    .version()
    .copy('resources/assets/images', 'public/images')
    .copy('node_modules/v3-assets/images', 'public/images')
    .copy('node_modules/svg-country-flags/svg', 'public/images/flags');

if (process.env.NODE_ENV === 'production') {
    mix.webpackConfig({
        stats: {
            assets: false,
        },
    });
}

mix.webpackConfig({
    resolve: {
        alias: {
            modernizr$: path.resolve(__dirname, './.modernizrrc.json'),
        },
        symlinks: false,
    },
    module: {
        rules: [
            {
                test: /\.modernizrrc.js$/,
                use: ['modernizr-loader'],
            },
            {
                test: /\.modernizrrc(\.json)?$/,
                use: ['modernizr-loader', 'json-loader'],
            },
        ],
    },
});

mix.babelConfig({
    presets: [
        [
            'env',
            {
                targets: {
                    browsers: [
                        'Chrome >= 52',
                        'FireFox >= 44',
                        'Safari >= 7',
                        'Explorer 11',
                        'last 4 Edge versions',
                    ],
                },
            },
        ],
        'stage-0',
        'react',
    ],
});
