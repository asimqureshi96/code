<?php

Route::get('fetch/nationalities', 'FetchController@nationalities');
