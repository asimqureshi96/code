<?php

if (!config('buzz.social_invite_enabled')) {
    return;
}

// Social invite
Route::group(['prefix' => 'social', 'as' => 'social::'], function () {
    Route::get('connections', 'SocialController@connections')->name('connections');
    Route::get('invites', 'SocialController@invites')->name('invites');
    Route::get('suggest', 'SuggestController@suggest')->name('suggest');
    Route::post('invite-connection', 'SocialController@inviteConnection')->name('invite-connection');
    Route::any('invite-email', 'SocialController@inviteEmail')->name('invite-email');
});
