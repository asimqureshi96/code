<?php

use Buzz\Control\Campaign\Property;

function registrationType($welcome = null)
{
    $knownTypes = ['visitor', 'vip', 'supplier','xlist'];

    if(request('type')){

        if(in_array(request('type'), $knownTypes)){
            session()->put('type', request('type'));

            return request('type');
        }
    }

    if(session()->get('type')){
        return session()->get('type');
    }

    if(customer() && customer()->properties){
        $type = customer()->getPropertyByIdentifier('type');

        if($type){
            return $type->value;
        }
    }

    if($welcome){
        return 'redirect';
    }else{
        return 'trade';
    }
}

function addProperty($identifier, $value)
{
    $property               = new Property();
    $property->parameter_id = $identifier;
    $property->value        = $value;
    $property->associate(customer());
    $property->save();
}
