<?php

namespace App\Http\Traits;

use RegCore\Http\Traits\BaseSeminar;

trait SeminarLocal
{
    use BaseSeminar;

    // Copy methods from BaseSeminar if you need changing them
    // Paste them below this comment
}
