<?php

namespace App\Http\Controllers;

use RegCore\Http\Controllers as Core;

class MeetingController extends Core\MeetingController
{
}
