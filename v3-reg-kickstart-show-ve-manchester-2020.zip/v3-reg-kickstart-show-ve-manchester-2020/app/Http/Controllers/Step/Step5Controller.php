<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step5Controller extends Step\Step5Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 5;


    protected function getRequired()
    {
        return [
            'which-of-the-following-are-you-most-interested-in-suppliers',
            'which-of-the-following-are-you-most-interested-in-venues',
        ];
    }

    protected function getQuestions()
    {
        return [
            'which-of-the-following-are-you-most-interested-in-suppliers',
            'which-of-the-following-are-you-most-interested-in-venues',
        ];
    }


    /**
     * @param QuestionHelper $questionHelper
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Buzz\Helpers\Exceptions\Error
     */
    public function render(QuestionHelper $questionHelper)
    {
        $type = registrationType();

        $questions = $questionHelper->getByIdentifiers($this->getQuestions());
        $required = $this->getRequired();

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required','type')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {

        $type = registrationType();

        $this->handleFlow();
        if (str_contains(strtolower(customer()->email),['@a-listevents','@bnceventshows','@hirespace','@venuesearchlondon','@venueview'])) {
            addProperty('type','xlist');
        }

        $required = $this->getRequired();

        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        return $this->next();
    }
}
