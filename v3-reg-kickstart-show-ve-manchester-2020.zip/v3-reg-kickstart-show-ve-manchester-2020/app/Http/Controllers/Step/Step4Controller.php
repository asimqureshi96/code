<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step4Controller extends Step\Step4Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 4;

    protected function getRequired()
    {
        return [
            'where-do-you-hold-your-events',
            'are-you-responsible-for-booking-travel-if-so-please-let-us-know-which-options',
            'what-type-of-events-do-you-organise',
        ];
    }

    protected function getQuestions()
    {
        return [
            'where-do-you-hold-your-events',
            'if-overseas-is-chosenhow-many-overseas-events-do-you-organise',
            'if-overseas-is-chosen-where-do-you-hold-your-overseas-events',
            'are-you-responsible-for-booking-travel-if-so-please-let-us-know-which-options',
            'what-type-of-events-do-you-organise',
        ];
    }
    protected function getRequiredSupplier()
    {
        return [
            'admissions-policy',
            'would-you-like-to-receive-a-regular-subscription-to-squaremeal',
        ];
    }

    protected function getQuestionsSupplier()
    {
        return [
            'how-would-you-like-to-receive-this',
            'admissions-policy',
            'would-you-like-to-receive-a-regular-subscription-to-squaremeal',
        ];
    }

    protected function getRequiredSpecific($type)
    {
        if ($type === 'supplier') {
            return $this->getRequiredSupplier();
        } else {
            return $this->getRequired();
        }
    }

    protected function getQuestionsSpecific($type)
    {
        if ($type === 'supplier') {
            return $this->getQuestionsSupplier();
        } else {
            return $this->getQuestions();
        }
    }

    public function render(QuestionHelper $questionHelper)
    {
        $type = registrationType();

        $questions = $questionHelper->getByIdentifiers($this->getQuestionsSpecific($type));

        $required = $this->getRequiredSpecific($type);

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required', 'type')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {
        $type = registrationType();

        if (str_contains(strtolower(customer()->email),['@a-listevents','@bnceventshows','@hirespace','@venuesearchlondon','@venueview'])) {
            addProperty('type','xlist');
        }

        if (isAnswered( 'would-you-like-to-receive-a-regular-subscription-to-squaremeal', 'yes')) {
            $required[] = 'how-would-you-like-to-receive-this';
        }

        $this->handleFlow();

        $required = $this->getRequiredSpecific($type);

        $answerHelper->answerMany($this->getQuestionsSpecific($type), request('questions'), $required);

        if ($type === 'supplier') {
            return $this->complete();
        } else {
            return $this->next();
        }
    }
}
