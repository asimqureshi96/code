<?php

Route::group(['prefix' => 'clone/', 'as' => 'clone.'], function () {
    Route::get('lead/{campaign_id}/{lead_id}', [
        'as'   => 'lead',
        'uses' => 'CloneController@lead',
    ]);

    Route::get('customer/{campaign_id}/{customer_id}', [
        'as'   => 'customer',
        'uses' => 'CloneController@customer',
    ]);


    Route::group(['prefix' => 'execute/', 'as' => 'execute.'], function () {
        Route::get('lead/{campaign_id}/{lead_id}', [
            'as'   => 'lead',
            'uses' => 'CloneController@executeLead',
        ]);

        Route::get('customer/{campaign_id}/{customer_id}', [
            'as'   => 'customer',
            'uses' => 'CloneController@executeCustomer',
        ]);
    });
});
