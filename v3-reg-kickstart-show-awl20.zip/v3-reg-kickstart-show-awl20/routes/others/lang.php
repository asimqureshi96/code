<?php

Route::get('lang/change-language/{identifier}', [
    'as'   => 'change-language',
    'uses' => 'LangController@changeLanguage',
]);
