<?php

if (!config('buzz.paid_show')) {
    return;
}

Route::group(['prefix' => 'basket'], function () {
    Route::get('/', 'BasketController@index')->name('basket');

    Route::group(['as' => 'basket::'], function () {
        Route::any('generate', 'BasketController@generate')->name('generate');
        Route::any('remove-by-product/{product_id}', 'BasketController@removeByProduct')->name('remove-by-product');
        Route::any('remove-basket-product/{basket_product_id}', 'BasketController@removeBasketProduct')->name('remove-basket-product');
        Route::any('remove-by-customer/{customer_id?}', 'BasketController@removeByCustomer')->name('remove-by-customer');
        Route::any('add-discount/{discount}', 'BasketController@addDiscount')->name('add-discount');
        Route::any('remove-discount/{discount?}', 'BasketController@removeDiscount')->name('remove-discount');
    });
});
