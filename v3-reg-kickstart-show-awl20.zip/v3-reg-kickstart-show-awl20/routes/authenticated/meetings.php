<?php

if (!config('buzz.web_module_meetings')) {
    return;
}

if (config('buzz.meetings_tool_enabled')) {
    Route::get('meetings', 'MeetingController@render')->name('meetings');
} else {
    Route::any('meetings', 'MeetingController@data')->name('meetings');
}
