<?php

namespace App\Providers;

use Buzz\Control\Campaign\CampaignSetting;
use Buzz\Control\Campaign\Stream;
use Illuminate\Support\ServiceProvider;
use Locale;

class CacheServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     * @throws \Exception
     */
    public function boot()
    {
        // only when in browser mode and not in maintenance mode
        if (app()->runningInConsole() || $this->app->isDownForMaintenance()) {
            return;
        }

        $must_recache = cache('stream_updated_at') !== app(Stream::class)->updated_at->timestamp;

        if ($must_recache) {
            $settings = (new CampaignSetting())->all();

            $locale = $settings['locale'];

            $locale['multilingual'] = count($settings['locale']['additional_languages'] ?: []) ? true : false;
            $languages              = array_merge(
                [$settings['locale']['language']],
                $settings['locale']['additional_languages'] ?: []
            );

            $locale['supported_languages'] = [];

            foreach ($languages as $language) {
                $locale['supported_languages'][$language] = [
                    'name'        => Locale::getDisplayLanguage($language, 'en'),
                    'native_name' => Locale::getDisplayLanguage($language, $language),
                    'iso'         => $language,
                ];
            }

            $settings['locale'] = $locale;

            cache()->forever('settings', $settings);
            cache()->forever('stream_updated_at', app(Stream::class)->updated_at->timestamp);
        }
    }
}
