<?php

namespace App\Http\Traits;

use RegCore\Http\Traits\Flow as BaseFlow;

trait Flow
{
    use BaseFlow;

    // Copy methods from BaseFlow if you need changing them
    // Paste them below this comment
    protected function complete()
    {


        customer()->badge_type_id = 'visitor';
        customer()->status = 'active';
        customer()->save();

        customer()->completeFlow();

        if (config('buzz.onsite')) {
            liveControlEvent('customer_completed', ['barcode' => customer()->barcode]);
            auth()->logout();

            return redirect()->route('step1');
        }

        session()->flash('flash_message', [
            'type'    => 'success',
            'title'   => transUi('Success!'),
            'message' => transUi('Registration complete!'),
        ]);

        return redirect()->route('thanks');
    }

}
