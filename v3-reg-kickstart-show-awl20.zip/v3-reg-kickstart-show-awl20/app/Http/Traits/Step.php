<?php

namespace App\Http\Traits;

use RegCore\Http\Traits\Step as BaseStep;

trait Step
{
    use BaseStep;

    // Copy methods from BaseStep if you need changing them
    // Paste them below this comment
}
