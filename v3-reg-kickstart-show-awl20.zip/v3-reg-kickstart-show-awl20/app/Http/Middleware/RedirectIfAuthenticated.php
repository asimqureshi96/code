<?php

namespace App\Http\Middleware;

use RegCore\Http\Middleware;

class RedirectIfAuthenticated extends Middleware\RedirectIfAuthenticated
{
}
