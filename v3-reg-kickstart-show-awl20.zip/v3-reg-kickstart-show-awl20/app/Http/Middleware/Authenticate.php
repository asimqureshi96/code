<?php

namespace App\Http\Middleware;

use RegCore\Http\Middleware;

class Authenticate extends Middleware\Authenticate
{
}
