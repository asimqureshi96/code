<?php

namespace App\Http;

use App\Http\Middleware;
use Buzz\Helpers\Middleware\GetIpCountry;
use Buzz\Helpers\Middleware\LangSelect;
use Illuminate\Foundation\Http\Kernel as HttpKernel;

class Kernel extends HttpKernel
{
    /**
     * The application's global HTTP middleware stack.
     * These middleware are run during every request to your application.
     *
     * @var array
     */
    protected $middleware = [
        \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
        \Illuminate\Foundation\Http\Middleware\CheckForMaintenanceMode::class,
        \Illuminate\Session\Middleware\StartSession::class,
        \Illuminate\View\Middleware\ShareErrorsFromSession::class,
    ];

    /**
     * The application's route middleware groups.
     *
     * @var array
     */
    protected $middlewareGroups = [
        'web' => [
            Middleware\Affiliate::class,
            Middleware\EncryptCookies::class,
            Middleware\Invite::class,
            Middleware\ResponseModifier::class,
            Middleware\UtmParameters::class,
            Middleware\VerifyCsrfToken::class,
            GetIpCountry::class,
            Middleware\RxPrePop::class,
        ],
    ];

    /**
     * The application's route middleware.
     * These middleware may be assigned to groups or used individually.
     *
     * @var array
     */
    protected $routeMiddleware = [
        'auth'         => Middleware\Authenticate::class,
        'auth.basic'   => \Illuminate\Auth\Middleware\AuthenticateWithBasicAuth::class,
        'form-closed'  => Middleware\FormClosed::class,
        'guest'        => Middleware\RedirectIfAuthenticated::class,
        'lang-select'  => LangSelect::class,
        'load-seminar' => Middleware\LoadSeminar::class,
        'step'         => Middleware\Step::class,
    ];
}
