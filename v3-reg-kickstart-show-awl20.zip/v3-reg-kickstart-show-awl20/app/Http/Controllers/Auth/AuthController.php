<?php

namespace App\Http\Controllers\Auth;

use RegCore\Http\Controllers\Auth;
use App\Http\Traits\Flow;

class AuthController extends Auth\AuthController
{
    use Flow;
}
