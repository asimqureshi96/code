<?php

namespace App\Http\Controllers;

use App\Http\Traits\Flow;
use App\Http\Traits\SeminarLocal;
use RegCore\Http\Controllers as Core;

class PaidSeminarController extends Core\PaidSeminarController
{
    use Flow;
    use SeminarLocal;
}
