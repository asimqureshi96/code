<?php

namespace App\Http\Controllers;

use App\Http\Traits\Flow;
use RegCore\Http\Controllers as Core;

class ProductController extends Core\ProductController
{
    use Flow;
}
