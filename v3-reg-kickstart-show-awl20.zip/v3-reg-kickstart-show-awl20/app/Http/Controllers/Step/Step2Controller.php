<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use RegCore\Http\Controllers\Step;

class Step2Controller extends Step\Step2Controller
{
    use Traits\Flow;
    use Traits\Step;
}
