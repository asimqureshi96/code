<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step3Controller extends Step\Step3Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 3;

    // required to be answered, open question can be submitted empty
    protected function getRequired()
    {
        return [
            'where-did-you-hear-about-the-show-tick-all-that-apply',
            'do-you-work-in-practice-or-in-business',
            'level-of-responsibility',
            'which-of-the-following-reflects-your-job-role-most-closely',
            'are-you-a-member-of-a-professional-body-or-association-tick-all-that-apply',
        ];
    }

    protected function getQuestions()
    {
        return [
            'where-did-you-hear-about-the-show-tick-all-that-apply',
            'do-you-work-in-practice-or-in-business',
            'level-of-responsibility',
            'which-of-the-following-reflects-your-job-role-most-closely',
            'if-in-business-how-many-partners-are-in-your-company',
            'if-in-practice-how-many-partners-are-in-your-company',
            'are-you-a-member-of-a-professional-body-or-association-tick-all-that-apply',
        ];
    }

    /**
     * @param QuestionHelper $questionHelper
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Buzz\Helpers\Exceptions\Error
     */
    public function render(QuestionHelper $questionHelper)
    {
        $questions = $questionHelper->getByIdentifiers($this->getQuestions());

        $required = $this->getRequired();

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {
        $this->handleFlow();

        $required = $this->getRequired();
        if (isAnswered('do-you-work-in-practice-or-in-business', 'practice')) {
            $required[] = 'if-in-practice-how-many-partners-are-in-your-company';
        }
        if (isAnswered('do-you-work-in-practice-or-in-business', 'business')) {
            $required[] = 'if-in-business-how-many-partners-are-in-your-company';
        }

        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        return $this->next();
    }
}

