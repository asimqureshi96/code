<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step4Controller extends Step\Step4Controller
{
    use Traits\Flow;
    use Traits\Step;
    protected $step = 4;

    // required to be answered, open question can be submitted empty
    protected function getRequired()
    {
        return [
            'where-do-you-get-your-industry-news-please-tick-all-that-apply',
            'what-made-you-decide-to-attend-accountingweb-live-please-tick-all-that-apply',
            'what-softwares-do-you-mainly-work-with',
        ];
    }

    protected function getQuestions()
    {
        return [
            'where-do-you-get-your-industry-news-please-tick-all-that-apply',
            'are-there-any-specific-companies-you-would-like-to-meet-at-accountingweb-live',
            'what-made-you-decide-to-attend-accountingweb-live-please-tick-all-that-apply',
            'what-softwares-do-you-mainly-work-with',
        ];
    }

    /**
     * @param QuestionHelper $questionHelper
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Buzz\Helpers\Exceptions\Error
     */
    public function render(QuestionHelper $questionHelper)
    {
        $questions = $questionHelper->getByIdentifiers($this->getQuestions());

        $required = $this->getRequired();

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {
        $this->handleFlow();

        $required = $this->getRequired();
        if (isAnswered('what-made-you-decide-to-attend-accountingweb-live-please-tick-all-that-apply', 'find-new-suppliers')) {
            $required[] = 'are-there-any-specific-companies-you-would-like-to-meet-at-accountingweb-live';
        }
        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        return $this->next();
    }
}
