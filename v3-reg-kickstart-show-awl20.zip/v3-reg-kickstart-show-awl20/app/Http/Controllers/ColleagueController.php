<?php

namespace App\Http\Controllers;

use App\Http\Traits\Flow;
use RegCore\Http\Controllers as Core;

class ColleagueController extends Core\ColleagueController
{
    use Flow;
}
