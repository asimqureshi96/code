<?php

namespace App\Http\Controllers;

use App\Http\Traits\Flow;
use Buzz\Control\Campaign\CustomerSeminar;
use Buzz\Control\Campaign\Invite;
use Buzz\Control\Campaign\Seminar;
use Buzz\Control\Campaign\Social;
use Buzz\Control\Filter;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers as Core;

class ProfileController extends Core\ProfileController
{
    use Flow;

    public function render()
    {
        $shareUrls = [];

        foreach (['facebook', 'twitter', 'linkedin', 'google'] as $provider) {
            $invite = new Invite([
                'status'   => 'sent',
                'provider' => $provider,
            ]);

            $invite = (new Social())->inviteShare(customer(), $invite);

            $shareUrls[$provider] = $invite->url;
        }

        $customerSocials = customer()->socials->pluck('provider');

        $filter   = (new Filter())->add('attendees.creator_id', 'is', customer()->id);
        $seminars = (new Seminar())->get($filter, 1, 1000, 'starts_at', 'asc');

        if ($seminars->isNotEmpty()) {
            $filter    = (new Filter())->add('creator_id', 'is', customer()->id)
                ->add('seminar_id', 'in', $seminars->pluck('id')->toArray());
            $attendees = (new CustomerSeminar())->expand(['customer'])->get($filter, 1, 1000);

            $seminars = $seminars->map(function ($seminar) use ($attendees) {
                $seminar->attendees_filtered = $attendees->where('seminar_id', $seminar->id);

                return $seminar;
            });
        }

        $webModulesOauthToken = null;

        // Generate Web Modules OAuth Token
        if (!config('buzz.onsite') && config('buzz.meetings_tool_enabled')) {
            $webModulesOauthToken = customer()->generateOAuthToken('web-modules', 60);
        }

        return view('profile', compact('shareUrls', 'customerSocials', 'seminars', 'webModulesOauthToken'));
    }

    protected function getRequired()
    {
        return [
            'terms-of-entry',
            'badge-policy',
        ];
    }

    protected function getQuestions()
    {
        return [
            'twitter-account',
            'tick-here-if-you-are-interested-in-exhibiting',
            'tick-here-if-you-would-like-to-subscribe',
            'terms-of-entry',
            'badge-policy',
        ];
    }
    public function renderPrivacy(QuestionHelper $questionHelper)
    {
        $questions = $questionHelper->getByIdentifiers($this->getQuestions());

        $required = $this->getRequired();

        return view('privacy', compact('questions', 'required'));
    }

    public function savePrivacy(AnswerHelper $answerHelper)
    {
        $required = $this->getRequired();

        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        customer()->save();

        session()->flash('flash_message', [
            'type'    => 'success',
            'title'   => transUi('Success!'),
            'message' => transUi('Your preferences have been saved'),
        ]);

        return redirect()->route('profile');
    }
}
