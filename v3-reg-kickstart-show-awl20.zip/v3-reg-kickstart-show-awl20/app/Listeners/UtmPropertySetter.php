<?php

namespace App\Listeners;

use RegCore\Listeners;

class UtmPropertySetter extends Listeners\UtmPropertySetter
{
}
