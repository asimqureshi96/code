<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Buzz config translations
    |--------------------------------------------------------------------------
     */

    'event'                     => [
        'name'  => 'Accounting Web Live',
        'year'  => '2020',
        'date'  => '2nd & 3rd December',
        'venue' => 'Ricoh Arena, Coventry',
    ],

    'meta_description'          => "Register now for Accounting Web Live 2020",

    // Email invite
    'email_invite_subject'      => "Join me at Accounting Web Live 2020",
    'email_invite_message'      => "I'm going to Accounting Web Live 2020. Join me at the innovative and interactive annual exhibition for accountants and finance professionals",

    // Linkedin invite
    'connection_invite_subject' => "Join me at Accounting Web Live 2020",
    'connection_invite_message' => "I’ve just registered for #AWEBlive! Who’s coming? @AWEBLive.\n\nhttps://kickstart-visitor.localhost/?invite=INVITE_CODE",
    'linkedin_share_message'    => 'I’ve just registered for #AWEBlive! Who’s coming? @AWEBLive.',

    // Twitter invite
    'twitter_share_message'     => 'I’ve just registered for #AWEBlive! Who’s coming? @AWEBLive.',

];
