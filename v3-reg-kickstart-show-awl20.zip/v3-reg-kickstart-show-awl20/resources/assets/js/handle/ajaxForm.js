/* eslint-disable func-names */
module.exports = function() {
    $(document).on('submit', 'form:not([data-buzz-ajax="false"])', function(e) {
        e.preventDefault();

        const $form = $(this);

        let data = {};
        let params = {};

        const method = $form.attr('method') ? $form.attr('method') : 'post';

        if (method.toLowerCase() === 'get') {
            params = $form.serialize();
        } else {
            data = new FormData($form[0]);

            for (const pair of data.entries()) {
                if (pair[1] instanceof File && pair[1].name == '' && pair[1].size == 0) {
                    data.delete(pair[0]);
                }
            }
        }

        Ajax.exec(method, $form.attr('action'), data, params, {
            withGlobalLoading: true,
            withErrors: false,
        })
            .then(json => {
                if (json.redirect) {
                    document.location.href = json.redirect;
                }
            })
            .catch(json => {
                store.commit('setErrors', json.error);
            });
    });
};
/* eslint-enable func-names */
