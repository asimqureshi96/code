<template>
    <div>
        <loading
            :text="transUi('Your recommendations loading. Please wait.')"
            v-if="loading"
        />

        <div v-else>
            <div v-if="exhibitors.length > 0">
                <h3 class="text-center">
                    {{ transUi('Based on your profile we recommend the following') }}
                </h3>

                <div class="well">
                    <h4>
                        {{ transUi('Exhibitors') }}
                    </h4>

                    <hr/>

                    <div class="row">
                        <div
                            class="col-md-6"
                            v-for="exhibitor in exhibitors"
                        >
                            <div class="media">
                                <div class="media-left">
                                    <a
                                        :href="exhibitor.details.website"
                                        target="_blank"
                                        v-if="exhibitor.details && exhibitor.details.website"
                                    >
                                        <img
                                            class="img-thumbnail media-object"
                                            width="100px"
                                            :src="exhibitor.image"
                                        />
                                    </a>

                                    <img
                                        class="img-thumbnail media-object"
                                        width="100px"
                                        :src="exhibitor.image"
                                        v-else
                                    />
                                </div>

                                <div class="media-body">
                                    <h4 class="media-heading">
                                        {{ exhibitor.name }}
                                    </h4>

                                    {{ exhibitor.description }}

                                    <div v-if="exhibitor.details && exhibitor.details.website">
                                        <a
                                            :href="exhibitor.details.website"
                                            target="_blank"
                                        >
                                            [{{ transUi('view website') }}]
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div
                class="alert alert-danger"
                v-else
            >
                {{ transUi('No recommendations found') }}!
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        url: {
            type: String,
            required: true,
        },
    },
    data() {
        return {
            exhibitors: null,
            loading: true,
        };
    },
    created() {
        this.fetchSuggestions();
    },
    methods: {
        fetchSuggestions() {
            Ajax.get(this.url)
                .then((jsonResponse) => {
                    this.exhibitors = jsonResponse.exhibitors;
                })
                .then(() => {
                    this.loading = false;
                });
        },
    },
};
</script>
