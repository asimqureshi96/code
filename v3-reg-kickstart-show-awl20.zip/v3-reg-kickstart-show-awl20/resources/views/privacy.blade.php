@extends('layout/auth')

@section('content')
    <div class="grey-section border-top-0 mb-3">
        <h3>{{ transUi('Communication Preferences') }}</h3>
        <p class="mb-0">{{ transUi('Update your preferences below') }}</p>
    </div>

    <form
        role="form"
        method="post"
        action="{{ route('save-privacy') }}"
    >

        <h5>If you have a Twitter account and would like @AWEBLive to follow you, please enter your Twitter username here</h5>
        <div style="max-width: 500px;">
        <answer
            :answer="{{ customer()->getAnswerByIdentifier('twitter-account') ?? 'null' }}"
            :question="{{ $questions['twitter-account'] }}"
            :required="{{ in_array('twitter-account', $required) ? 'true' : 'false' }}"
            :show-title="false"
            :with-label="false"
        ></answer>
        </div>
        <buzz-checkbox
            name="questions[tick-here-if-you-are-interested-in-exhibiting][options][i-agree][key]"
            :required="{{ in_array('tick-here-if-you-are-interested-in-exhibiting', $required) ? 'true' : 'false' }}"
            true-value="5efdd260-5fb6-11ea-9dc4-000000000000"
            :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('tick-here-if-you-are-interested-in-exhibiting') ? ['5efdd260-5fb6-11ea-9dc4-000000000000'] : [])}}"
        >
    <span>
        Tick here if you are interested in exhibiting at or advertising with AccountingWEB Live </span>
        </buzz-checkbox>
        <br>
        <buzz-checkbox
            name="questions[tick-here-if-you-would-like-to-subscribe][options][i-agree][key]"
            :required="{{ in_array('tick-here-if-you-would-like-to-subscribe', $required) ? 'true' : 'false' }}"
            true-value="6a3da1c8-5fb6-11ea-8b6f-000000000000"
            :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('tick-here-if-you-would-like-to-subscribe') ? ['6a3da1c8-5fb6-11ea-8b6f-000000000000'] : [])}}"
        >
            <br>
    <span>
        Tick here if you would like to subscribe to AccountingWEB’s e-newsletter </span>
        </buzz-checkbox>


        <h5>Data Protection</h5>

        <p>Sift Limited collects your data in order to register you for entry to AccountingWEB and send you information about the content and activities which form an integral part of it.

            We may also from time to time send you information about our other related events and products which we believe will be of interest to you. You will have the option to unsubscribe at any point.</p>
        <buzz-checkbox
            name="questions[terms-of-entry][options][i-agree][key]"
            :required="{{ in_array('terms-of-entry', $required) ? 'true' : 'false' }}"
            true-value="a3f0c9f4-5fb6-11ea-9b61-000000000000"
            :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('terms-of-entry') ? ['a3f0c9f4-5fb6-11ea-9b61-000000000000'] : [])}}"
        >
            <br>
    <span class="required">
       I have read, understood and consent to the Terms of Entry.</span>
        </buzz-checkbox>
        <br>
        <buzz-checkbox
            name="questions[badge-policy][options][i-agree][key]"
            :required="{{ in_array('badge-policy', $required) ? 'true' : 'false' }}"
            true-value="b2c8b478-5fb6-11ea-94ec-000000000000"
            :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('badge-policy') ? ['b2c8b478-5fb6-11ea-94ec-000000000000'] : [])}}"
        >
            <br>
    <span class="required">
       I have read, understood and consent to the Badge Policy.</span>
        </buzz-checkbox>

        <p>We (Sift Limited) may also like to contact you occasionally on behalf of carefully selected third party companies who we believe you will benefit from hearing from. Please select below if you are happy to hear from such companies.</p>

        <button
            type="submit"
            class="btn btn-primary btn-block mt-4"
        >
            {{ transUi('Submit') }}
        </button>
    </form>
@endsection
