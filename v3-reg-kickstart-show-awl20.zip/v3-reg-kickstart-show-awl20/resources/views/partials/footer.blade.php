<div class=" container footer-top">
    <div class="row mt-2">

        <div class="col-md-3 text-center desktopFooter">
            <h4 class="footer-header mt-2"> Venue Details <i class="fa fa-building"></i></h4>
            <hr class="hr1">
            <p class="footer-text"> The Ricoh Arena <br>
                Judds Ln, Coventry, <br> CV6 6GE</p>
        </div>
        <div class="col-md-3 text-center desktopFooter">
            <h4 class="footer-header mt-2"> Opening Times <i class="fa fa-clock-o"></i></h4>
            <hr class="hr1">
            <p
                class="footer-text"
                style="margin-bottom: 5px;"
            > 2nd December 2020 10am – 5pm</p>
            <p class="footer-text"> 3rd December 2020 10am – 4pm </p>

            <a
                href="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/Accounting%20Web%20Live%202020%20%281%29.ics"
                target="_blank"
            >
                <button class="btn btn-secondary mt-2"> Add to Calendar</button>
            </a>
        </div>
        <div class="col-md-3 text-center desktopFooter">
            <div class="text-center">
                <h4 class="footer-header mt-2"> Useful Links <i class="fa fa-link"></i></h4>
                <hr class="hr1">

                <a
                    href="https://www.accountingweblive.co.uk/terms-conditions"
                    target="_blank"
                    class="footer-text"
                ><p class="footer-text" style="margin-bottom: 4px;"> Terms & Conditions</p></a>
                <a
                    href="https://www.accountingweblive.co.uk/privacy-policy"
                    target="_blank"
                ><p class="footer-text"> Privacy Policy</p></a>
                <a
                    class="footer-text"
                    href="https://www.facebook.com/accountingwebuk"
                    target="_blank"
                ><i class="fa fa-facebook-square fa-2x mr-2"></i></a>
                <a
                    class="footer-text"
                    href="https://twitter.com/AWEBLive"
                    target="_blank"
                ><i class="fa fa-twitter-square fa-2x mr-2"></i></a>
                <a
                    class="footer-text"
                    href="https://www.linkedin.com/company/accountingweb.co.uk/"
                    target="_blank"
                ><i class="fa fa-linkedin-square fa-2x mr-2"></i></a>
                <a
                    class="footer-text"
                    href="https://www.instagram.com/accountingwebuk/"
                    target="_blank"
                ><i class="fa fa-instagram fa-2x"></i></a>

            </div>
        </div>
        <div class="col-md-3 text-center desktopFooter">
            <h4 class="footer-header mt-2"> Organised by <i class="fa fa-users"></i></h4>
            <hr class="hr1">

            <a href="https://www.sift.co.uk/" target="_blank">
                <img
                    class="my-2"
                    style="width: 123px; height: 35px;"
                    src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/Sift.png"
                    alt="SIFT MEDIA"
                ></a>
            <br>
            <a href="https://www.seventythreemedia.com/" target="_blank">
                <img
                    class="mb-2"
                    style="width: 117px; height: 40px;"
                    src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/73_logo_3.png"
                    alt="73 LOGO"
                ></a>
        </div>


        <div class="col-md-12 text-center desktopFooter mb-2">
            <div class="text-center">
            </div>
        </div>
        <div class="col-md-12 text-center mobileFooter">
            <h4 class="footer-header mt-2"> Venue Details <i class="fa fa-building"></i></h4>
            <h5 class="footer-text"> The Ricoh Arena <br>
                Judds Ln, Coventry, <br> CV6 6GE</h5>
        </div>
        <div class="col-md-5 text-center mobileFooter">
            <h4 class="footer-header mt-2"> Date and Times <i class="fa fa-clock-o"></i></h4>
            <h5 class="footer-text"> Wednesday 2nd December 2020 <br>10am – 5pm</h5>
            <h5 class="footer-text"> Thursday 3rd December 2020 <br> 10am – 4pm </h5>
        </div>
        <div class="col-md-12 text-center mobileFooter mb-2">
            <a
                href="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/Accounting%20Web%20Live%202020%20%281%29.ics"
                target="_blank"
            >
                <button class="btn btn-secondary mt-2"> Add to Calendar</button>
            </a>
        </div>
        <div class="col-md-4 text-center mobileFooter mb-2">
            <h4 class="footer-header mt-2"> Follow Us</h4>
            <a
                class="footer-text"
                href="https://www.facebook.com/accountingwebuk"
                target="_blank"
            ><i class="fa fa-facebook-square fa-2x mr-2"></i></a>
            <a
                class="footer-text"
                href="https://twitter.com/AWEBLive"
                target="_blank"
            ><i class="fa fa-twitter-square fa-2x mr-2"></i></a>
            <a
                class="footer-text"
                href="https://www.linkedin.com/company/accountingweb.co.uk/"
                target="_blank"
            ><i class="fa fa-linkedin-square fa-2x mr-2"></i></a>
            <a
                class="footer-text"
                href="https://www.instagram.com/accountingwebuk/"
                target="_blank"
            ><i class="fa fa-instagram fa-2x"></i></a>

        </div>

        <div class="col-md-3 text-center mobileFooter">
            <h4 class="footer-header mt-2"> Organised by <i class="fa fa-users"></i></h4>
            <a href="https://www.sift.co.uk/" target="_blank">
            <img
                class="my-2"
                style="width: 123px; height: 35px;"
                src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/Sift.png"
                alt="SIFT MEDIA"
            ></a>
            <br>
            <a href="https://www.seventythreemedia.com/" target="_blank">
            <img
                class="mb-2"
                style="width: 117px; height: 40px;"
                src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/73_logo_3.png"
                alt="73 LOGO"
            ></a>
        </div>
    </div>

</div>
<footer>
    <div class="row">
        <div class="col-md-12 text-center desktopFooter">
            <p
                style="color: black"
                class="mr-3"
            >
                Powered by
                <a
                    href="https://www.livebuzz.co.uk"
                    target="_blank"
                >
                    <img
                        class="my-2 ml-1"
                        src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/livebuzz-dark.png"
                        alt="LiveBuzz Logo"
                    >
                </a>
            </p>
        </div>

        <div class="col-md-12 mobileFooter text-center">
            <p
                style="color: black"
                class="mr-3"
            >
                Powered by
                <a
                    href="https://www.livebuzz.co.uk"
                    target="_blank"
                >
                    <img
                        class="my-2"
                        src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/livebuzz-dark.png"
                        alt="LiveBuzz Logo"
                    >
                </a>
            </p>
        </div>
    </div>
</footer>
