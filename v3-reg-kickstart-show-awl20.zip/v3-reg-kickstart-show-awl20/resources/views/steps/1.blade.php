<p style="font-size:16px; color: white;" class="alert alert-primary footer-text">AccountingWEB Live  is a new kind of accounting exhibition, with content at its heart as well as the best in accounting tech and services.
<br>
    Network with fellow accounting professionals, discover the latest accounting tech, earn CPD points and tactics to grow your firm. <br> AccountingWEB Live  has everything you need from an accounting exhibition! <br>
<br>
    Creating connections. Making conversations. Powering a community. Meet old friends and make new ones at AccountingWEB Live
<br> <br>
    Please complete the form below to register for the event. Admission is FREE.
    <br>
    <br>All fields marked with * must be completed.

</p>
<h5>{{ transUi('Personal information') }}</h5>
<p class="help-block">{{ transUi('Enter your personal details') }}</p>

<titles
    title="{{ customer()->title ?? '' }}"
    :required="true"
></titles>

<buzz-input
    name="first_name"
    placeholder="{{ transUi('First name') }}"
    value="{{ customer()->first_name ?? '' }}"
    :required="true"
></buzz-input>

<buzz-input
    name="last_name"
    placeholder="{{ transUi('Last name') }}"
    value="{{ customer()->last_name ?? '' }}"
    :required="true"
></buzz-input>

<buzz-input
    name="job_title"
    placeholder="{{ transUi('Job title') }}"
    value="{{ customer()->job_title ?? '' }}"
    :required="true"
></buzz-input>

<buzz-input
    name="company"
    placeholder="{{ transUi('Company') }}"
    value="{{ customer()->company ?? '' }}"
    :required="true"
></buzz-input>
<answer
    @if (customer())
    :answer="{{ customer()->getAnswerByIdentifier('website') ?? 'null' }}"
    @endif
    :question="{{ $questions['website']}}"
    :required="{{ in_array('website', $required) ? 'true' : 'false' }}"
    :show-title="false"
    :placeholder="('Website')"

></answer>
<buzz-phone
    name="telephone"
    placeholder="{{ transUi('Telephone') }}"
    value="{{ $phones['telephone'] ?? '' }}"
    :required="true"
></buzz-phone>
<p class="help-block" style="margin-bottom: 0;">*We may text you to remind you of show dates</p>
<buzz-phone
    name="mobile"
    placeholder="{{ transUi('Mobile') }}"
    value="{{ $phones['mobile'] ?? '' }}"
></buzz-phone>

@if (passwordIsEnabled())
    <h5 class="mt-4">{{ transUi('Login information') }}</h5>
    <p class="help-block">{{ transUi('Enter your desired login details') }}</p>
@endif

<buzz-input
    name="email"
    type="email"
    placeholder="{{ transUi('Email') }}"
    value="{{ customer()->email ?? '' }}"
    :required="true"
></buzz-input>

<buzz-input
    name="email_confirmation"
    type="email"
    placeholder="{{ transUi('Confirm email') }}"
    value="{{ customer()->email ?? '' }}"
    :required="true"
></buzz-input>

@if (passwordIsEnabled())
    <buzz-password
        :optional="{{ passwordIsOptional() ? 'true' : 'false' }}"
        :required="true"
    ></buzz-password>
@endif
