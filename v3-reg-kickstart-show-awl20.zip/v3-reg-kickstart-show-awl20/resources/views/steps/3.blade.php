<answer
    :answer="{{ customer()->getAnswerByIdentifier('where-did-you-hear-about-the-show-tick-all-that-apply') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['where-did-you-hear-about-the-show-tick-all-that-apply'] }}"
    :required="{{ in_array('where-did-you-hear-about-the-show-tick-all-that-apply', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('do-you-work-in-practice-or-in-business') ?? 'null' }}"
    :question="{{ $questions['do-you-work-in-practice-or-in-business'] }}"
    :column-count="2"
    :required="{{ in_array('do-you-work-in-practice-or-in-business', $required) ? 'true' : 'false' }}"
>
    <answer
        :answer="{{ customer()->getAnswerByIdentifier('if-in-business-how-many-partners-are-in-your-company') ?? 'null' }}"
        :question="{{ $questions['if-in-business-how-many-partners-are-in-your-company'] }}"
        :required="true"
        :column-count="2"
        slot="business::after"
    ></answer>
    <answer
        :answer="{{ customer()->getAnswerByIdentifier('if-in-practice-how-many-partners-are-in-your-company') ?? 'null' }}"
        :question="{{ $questions['if-in-practice-how-many-partners-are-in-your-company'] }}"
        :required="true"
        :column-count="2"
        slot="practice::after"
    ></answer>
</answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('which-of-the-following-reflects-your-job-role-most-closely') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['which-of-the-following-reflects-your-job-role-most-closely'] }}"
    :required="{{ in_array('which-of-the-following-reflects-your-job-role-most-closely', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('level-of-responsibility') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['level-of-responsibility'] }}"
    :required="{{ in_array('level-of-responsibility', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('are-you-a-member-of-a-professional-body-or-association-tick-all-that-apply') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['are-you-a-member-of-a-professional-body-or-association-tick-all-that-apply'] }}"
    :required="{{ in_array('are-you-a-member-of-a-professional-body-or-association-tick-all-that-apply', $required) ? 'true' : 'false' }}"
></answer>
