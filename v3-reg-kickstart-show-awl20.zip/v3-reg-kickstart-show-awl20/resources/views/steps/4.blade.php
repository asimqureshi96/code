<answer
    :answer="{{ customer()->getAnswerByIdentifier('what-softwares-do-you-mainly-work-with') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['what-softwares-do-you-mainly-work-with'] }}"
    :required="{{ in_array('what-softwares-do-you-mainly-work-with', $required) ? 'true' : 'false' }}"
></answer>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('what-made-you-decide-to-attend-accountingweb-live-please-tick-all-that-apply') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['what-made-you-decide-to-attend-accountingweb-live-please-tick-all-that-apply'] }}"
    :required="{{ in_array('what-made-you-decide-to-attend-accountingweb-live-please-tick-all-that-apply', $required) ? 'true' : 'false' }}"
>

    <answer
        :answer="{{ customer()->getAnswerByIdentifier('are-there-any-specific-companies-you-would-like-to-meet-at-accountingweb-live') ?? 'null' }}"
        :question="{{ $questions['are-there-any-specific-companies-you-would-like-to-meet-at-accountingweb-live'] }}"
        :required="true"
        slot="find-new-suppliers::after"
    ></answer>
</answer>

<answer
    :answer="{{ customer()->getAnswerByIdentifier('where-do-you-get-your-industry-news-please-tick-all-that-apply') ?? 'null' }}"
    :column-count="2"
    :question="{{ $questions['where-do-you-get-your-industry-news-please-tick-all-that-apply'] }}"
    :required="{{ in_array('where-do-you-get-your-industry-news-please-tick-all-that-apply', $required) ? 'true' : 'false' }}"
></answer>
