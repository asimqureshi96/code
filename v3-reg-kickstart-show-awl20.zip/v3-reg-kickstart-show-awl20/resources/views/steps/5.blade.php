<h5 class="required">Please confirm you are over 18 years of age?</h5>
<buzz-checkbox
    name="questions[confirm-you-are-18][options][i-can][key]"
    :required="{{ in_array('confirm-you-are-18', $required) ? 'true' : 'false' }}"
    true-value="9a2aca70-6441-11ea-8f57-000000000000"
    :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('confirm-you-are-18') ? ['9a2aca70-6441-11ea-8f57-000000000000'] : [])}}"
>
    <span class="required">
        I can confirm I am over 18 years of age </span>
</buzz-checkbox>
<h5>If you have a Twitter account and would like @AWEBLive to follow you, please enter your Twitter username here</h5>
<answer
    :answer="{{ customer()->getAnswerByIdentifier('twitter-account') ?? 'null' }}"
    :question="{{ $questions['twitter-account'] }}"
    :required="{{ in_array('twitter-account', $required) ? 'true' : 'false' }}"
    :placeholder="('Twitter Account')"
    :show-title="false"
    :with-label="false"
></answer>

<buzz-checkbox
    name="questions[tick-here-if-you-are-interested-in-exhibiting][options][i-agree][key]"
    :required="{{ in_array('tick-here-if-you-are-interested-in-exhibiting', $required) ? 'true' : 'false' }}"
    true-value="5efdd260-5fb6-11ea-9dc4-000000000000"
    :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('tick-here-if-you-are-interested-in-exhibiting') ? ['5efdd260-5fb6-11ea-9dc4-000000000000'] : [])}}"
>
    <span>
        Tick here if you are interested in exhibiting at or advertising with AccountingWEB Live </span>
</buzz-checkbox>
<buzz-checkbox
    name="questions[tick-here-if-you-would-like-to-subscribe][options][i-agree][key]"
    :required="{{ in_array('tick-here-if-you-would-like-to-subscribe', $required) ? 'true' : 'false' }}"
    true-value="6a3da1c8-5fb6-11ea-8b6f-000000000000"
    :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('tick-here-if-you-would-like-to-subscribe') ? ['6a3da1c8-5fb6-11ea-8b6f-000000000000'] : [])}}"
>
    <span>
        Tick here if you would like to subscribe to AccountingWEB’s e-newsletter </span>
</buzz-checkbox>


<h5>Data Protection</h5>

<p>Sift Limited collects your data in order to register you for entry to AccountingWEB and send you information about the content and activities which form an integral part of it.

    We may also from time to time send you information about our other related events and products which we believe will be of interest to you. You will have the option to unsubscribe at any point.</p>
<buzz-checkbox
    name="questions[terms-of-entry][options][i-agree][key]"
    :required="{{ in_array('terms-of-entry', $required) ? 'true' : 'false' }}"
    true-value="a3f0c9f4-5fb6-11ea-9b61-000000000000"
    :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('terms-of-entry') ? ['a3f0c9f4-5fb6-11ea-9b61-000000000000'] : [])}}"
>
    <span class="required">
       I have read, understood and consent to the
    <a
            target="terms"
            id="termsLink"
        style="color: black;"
        href="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/AWL20%20-%20Terms%20and%20Conditions.pdf"
        >Terms of Entry </a>.


<iframe
    src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/AWL20%20-%20Terms%20and%20Conditions.pdf"
    name="terms"
    id="tandc"
    style="display: none; width: 100%; height: 600px;"
></iframe>

    </span>
</buzz-checkbox>

@push('js')
    <script type="text/javascript">
        $(document).on('click', '#termsLink', function() {
            $('#tandc').slideDown();
        });
        $(document).on('click', '#termsLink', function() {
            $('#tandc').hide();
        });
    </script>
@endpush



<buzz-checkbox
    name="questions[badge-policy][options][i-agree][key]"
    :required="{{ in_array('badge-policy', $required) ? 'true' : 'false' }}"
    true-value="b2c8b478-5fb6-11ea-94ec-000000000000"
    :checked-values="{{ json_encode(customer() && customer()->getAnswerByIdentifier('badge-policy') ? ['b2c8b478-5fb6-11ea-94ec-000000000000'] : [])}}"
>
    <span class="required">
       I have read, understood and consent to the
    <a
        target="terms1"
        id="termsLink1"
        style="color: black;"
        href="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/AWL20%20-%20Admission%20Policy.pdf"
    >Admission Policy</a>.


<iframe
    src="https://livebuzz-production.s3.eu-west-1.amazonaws.com/sift-media/campaign/a83ba130-5e14-11ea-94e2-000000000000/AWL20%20-%20Admission%20Policy.pdf"
    name="terms1"
    id="tandc1"
    style="display: none; width: 100%; height: 600px;"
></iframe>

    </span>
</buzz-checkbox>

@push('js')
    <script type="text/javascript">
        $(document).on('click', '#termsLink1', function() {
            $('#tandc1').slideDown();
        });
        $(document).on('click', '#termsLink1', function() {
            $('#tandc1').hide();
        });
    </script>
@endpush

