<template>
    <div>
        <div class="row connections-container">
            <div
                class="col-xs-6 col-md-3 connections-block"
                v-for="(connection, index) in connections"
            >
                <connection-item :connection="connection"/>

                <button
                    @click.prevent="connectionIndex = index"
                    class="btn btn-success btn-sm btn-block"
                    style="margin-top:5px"
                >
                    {{ transUi('Invite') }}
                </button>
            </div>
        </div>

        <connection-invite
            :invite-connection-url="inviteConnectionUrl"
            :show="connectionIndex !== null"
            @close="connectionIndex = null"
            v-model="connections[connectionIndex]"
        />
    </div>
</template>

<script>
import ConnectionInvite from './ConnectionInvite.vue';
import ConnectionItem from './ConnectionItem.vue';

export default {
    props: {
        connections: {
            type: Array,
            default: () => [],
        },
        inviteConnectionUrl: {
            type: String,
            required: true,
        },
    },
    components: {
        ConnectionInvite,
        ConnectionItem,
    },
    data() {
        return {
            connectionIndex: null,
        };
    },
};
</script>

<style>
    .connections-container {
        max-height: 350px;
        overflow: auto;
    }

    .connections-block {
        padding-bottom: 20px;
    }
</style>
