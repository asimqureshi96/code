<template>
    <div>
        <template v-if="element.type === 'QuestionOptionGroup'">
            <radio-group
                :collapsed="collapsed"
                :context="context"
                :element="element"
            >
                <radio-option
                    v-for="subElement in element.elements"
                    :key="`element_${subElement.id}`"
                    v-model="myValue"
                    :element="subElement"
                    :context="context"
                />
            </radio-group>
        </template>
        <template v-else-if="element.type === 'QuestionOption'">
            <radio-option
                v-model="myValue"
                :element="element"
                :context="context"
            />
        </template>
    </div>
</template>

<script>
import RadioOption from 'v3-assets/js/components/Answer/Radio/Option.vue';
import RadioGroup from './Group.vue';

export default {
    components: {
        RadioGroup,
        RadioOption,
    },
    props: {
        context: {
            type: Object,
            required: true,
        },
        collapsed: {
            type: Boolean,
            default: true,
        },
        element: {
            type: Object,
            required: true,
        },
        value: {
            default: null,
        },
    },
    computed: {
        myValue: {
            get() {
                return this.value;
            },
            set(value) {
                this.$emit('input', value);
            }
        }
    }
}
</script>
