<template>
    <div>
        <div v-if="design === 'default'">
            <heading v-bind="$props"/>

            <div class="row">
                <div
                    v-for="optionsChunk in chunkIt(filteredElements, columnCount)"
                    :class="columnClass(columnNumber)"
                >
                    <div v-for="element in optionsChunk">
                        <radio-element
                            v-model="option"
                            :element="element"
                            :key="`element_${element.id}`"
                            :context="context"
                            :collapsed="collapsed"
                        />
                    </div>
                </div>
            </div>
        </div>

        <div v-if="design === 'row'">
            <div
                class="row hide-under-md"
                v-if="firstRow"
            >
                <div :class="columnCount !== 1 ? columnClass(12 - columnCount) : columnClass(columnNumber)"/>
                <div
                    v-for="o in filteredOptions"
                    :class="columnClass(columnNumber) + ' row-design'"
                >{{ o.translation.body }}</div>
            </div>

            <div class="row">
                <div :class="columnCount !== 1 ? columnClass(12 - columnCount) : columnClass(columnNumber)">
                    <heading v-bind="$props"/>
                </div>
                <div
                    v-for="o in filteredOptions"
                    :class="columnClass(columnNumber) + ' row-design'"
                >
                    <div>
                        <buzz-radio
                            v-model="option"
                            :name="getName('[options][0][key]')"
                            :required="required"
                            :true-value="o.id"
                        >
                            <span class="d-md-none">{{ o.translation.body }}</span>
                        </buzz-radio>

                        <template v-if="isSelected(o)">
                            <input
                                :name="getName('[options][0][identifier]')"
                                :value="o.identifier"
                                type="hidden"
                            >

                            <div v-if="isOpen(o)">
                                <buzz-input
                                    v-if="o && o.open === 'yes'"
                                    v-model="texts[o.id]"
                                    :autofocus="true"
                                    :error-identifier="getErrorIdentifier(o.identifier)"
                                    :label="o.translation.body"
                                    :name="getName('[options][0][text]')"
                                    :placeholder="o.translation.description || transUi('Please specify')"
                                    :required="isOpenRequired(o)"
                                />
                            </div>
                        </template>

                        <slot
                            v-if="isSelected(o)"
                            :name="o.identifier"
                        />
                    </div>
                </div>
            </div>
        </div>

        <error :identifier="getErrorIdentifier('')"/>

        <div
            v-for="o in filteredOptions"
            class="mt-4"
        >
            <slot
                v-if="isSelected(o)"
                :name="o.identifier + '::after'"
            />
        </div>
    </div>
</template>

<script>
import Base from 'v3-assets/js/components/Answer/Base.vue';
import Heading from 'v3-assets/js/components/Answer//Heading.vue';
import RadioElement from './Radio/Element.vue';

export default {
    extends: Base,
    components: {
        Heading,
        RadioElement,
    },
    props: {
        firstRow: {
            type: Boolean,
            default: false,
        },
        collapsed: {
            type: Boolean,
            default: true,
        },
    },
    data() {
        return {
            option: null,
            texts: {},
        };
    },
    created() {
        if (this.answer) {
            this.option = _.head(this.answer.options).question_option_id;

            _.each(this.answer.options, option => {
                if (!_.isEmpty(option.text)) {
                    this.texts[option.question_option_id] = option.text;
                }
            });
        }

        this.$slots = this.$parent.$slots;
    },
    methods: {
        isSelected(option) {
            if (!this.option) {
                return false;
            }

            return this.option === option.id;
        },
    },
};
</script>
