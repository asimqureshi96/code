<template>
    <div v-if="question.active === 'yes' || answer">
        <div
            :allow-html="allowHtml"
            :answer="answer"
            :check-none-option="checkNoneOption"
            :class="answerClasses"
            :collapsed="collapsed"
            :column-count="columnCount"
            :design="design"
            :first-row="firstRow"
            :is="'answer-' + question.type"
            :limit-answers="limitAnswers"
            :name="name"
            :placeholder="placeholder || transUi('Please specify')"
            :question="question"
            :required="required"
            :show-description="showDescription"
            :show-title="showTitle"
            :with-label="withLabel"
        />

        <input
            :name="'question_types[' + question.identifier + ']'"
            :value="question.type"
            type="hidden"
        >
    </div>
</template>

<script>
import AnswerRadio from './Radio.vue';

export default {
    components: {
        AnswerRadio,
    },
    props: {
        question: {
            type: Object,
            required: true,
        },
        answer: {
            type: Object,
            default() {
                return null;
            },
        },
        collapsed: {
            type: Boolean,
            default: true,
        },
        design: {
            type: String,
            default: 'default',
        },
        name: {
            type: String,
            default: '',
        },
        required: {
            type: Boolean,
            default: false,
        },
        limitAnswers: {
            type: Number,
            default: 0,
        },
        checkNoneOption: {
            type: String,
            default: null,
        },
        showTitle: {
            type: Boolean,
            default: true,
        },
        showDescription: {
            type: Boolean,
            default: true,
        },
        allowHtml: {
            type: Boolean,
            default: false,
        },
        columnCount: {
            type: Number,
            default: 1,
        },
        placeholder: {
            type: String,
            default: null,
        },
        withLabel: {
            type: Boolean,
            default: true,
        },
        firstRow: {
            type: Boolean,
            default: false,
        },
        extraAnswerClasses: {
            type: String,
            default: '',
        },
    },
    computed: {
        answerClasses() {
            let classes = `buzz-answer mb-4 buzz-answer-${this.design}`;

            if (this.extraAnswerClasses.length) {
                classes += ` ${this.extraAnswerClasses}`;
            }

            return classes;
        },
    },
};
</script>
