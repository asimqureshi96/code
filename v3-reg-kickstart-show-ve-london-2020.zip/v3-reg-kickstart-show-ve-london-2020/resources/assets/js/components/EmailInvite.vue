<template>
    <modal
        @close="close()"
        v-if="show"
    >
        <template slot="title">
            <h4 class="modal-title">
                {{ transUi('Invite') }} {{ email }}
            </h4>
        </template>

        <template slot="body">
            <div class="form-group">
                <label>
                    {{ transUi('Subject') }}
                </label>

                <input
                    :placeholder="transUi('Enter subject')"
                    class="form-control"
                    data-autofocus
                    type="text"
                    v-model="subject"
                />
            </div>

            <div class="form-group">
                <label>
                    {{ transUi('Message') }}
                </label>

                <textarea
                    :placeholder="transUi('Enter message')"
                    class="form-control"
                    v-model="message"
                ></textarea>
            </div>
        </template>

        <template slot="buttons">
            <button
                :class="{'btn' : true, 'btn-primary': true, 'loading' :loading}"
                :disabled="!isEmailInviteValid || loading"
                @click.prevent="sendEmailInvite"
                type="button"
            >
                {{ transUi('Send invite') }}
            </button>
        </template>
    </modal>
</template>

<script>
export default {
    props: {
        show: {
            type: Boolean,
            required: true,
        },
        email: {
            type: String,
            default: '',
        },
        inviteEmailUrl: {
            type: String,
            required: true,
        },
        value: {
            type: Array,
            required: true,
        },
    },
    data() {
        return {
            emailInvites: this.value,
            loading: false,
            message: '',
            subject: '',
        };
    },
    created() {
        this.message = this.transUi('email_invite_message');
        this.subject = this.transUi('email_invite_subject');
    },
    computed: {
        isEmailInviteValid() {
            return !!(this.email && this.subject && this.message);
        },
    },
    methods: {
        sendEmailInvite() {
            if (this.isEmailInviteValid) {
                this.loading = true;

                const data = {
                    email: this.email,
                    message: this.message,
                    subject: this.subject,
                };

                Ajax.post(this.inviteEmailUrl, data)
                    .then((jsonResponse) => {
                        this.loading = false;
                        this.emailInvites.push(jsonResponse);
                        this.$emit('input', this.emailInvites);
                        this.close();
                    })
                    .catch((error) => {
                        this.loading = false;
                        this.$emit('error', error);
                    });
            }
        },
        close() {
            this.message = this.transUi('email_invite_message');
            this.subject = this.transUi('email_invite_subject');
            this.$emit('close');
        },
    },
};
</script>
