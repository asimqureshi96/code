<template>
    <div id="map">
        <l-map
            :center="center"
            :zoom="zoom"
        >
            <l-tile-layer
                :attribution="attribution"
                :url="url"
            />
            <l-marker :lat-lng="marker"/>
        </l-map>
    </div>
</template>

<script>
import { LMap, LTileLayer, LMarker } from 'vue2-leaflet';

export default {
    components: {
        'l-map': LMap,
        'l-tile-layer': LTileLayer,
        'l-marker': LMarker,
    },
    props: {
        lat: {
            type: Number,
            required: true,
        },
        lng: {
            type: Number,
            required: true,
        },
        zoom: {
            type: Number,
            default: 13,
        },
    },
    data() {
        return {
            attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors',
            center: window.L.latLng(47.413220, -1.219482),
            marker: window.L.latLng(47.413220, -1.219482),
            url: 'https://{s}.tile.osm.org/{z}/{x}/{y}.png',
        };
    },
    mounted() {
        this.center = window.L.latLng(this.lat, this.lng);
        this.marker = this.center;
    },
};
</script>
