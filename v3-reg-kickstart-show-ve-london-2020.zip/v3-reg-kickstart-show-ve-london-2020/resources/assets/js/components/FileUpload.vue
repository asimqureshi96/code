<template>
    <div>
        <h5 class="h5 mb-0">
            <slot/>

            <span
                style="color: red;"
                v-if="required"
            >
                *
            </span>
        </h5>

        <small>
            Allowed types: {{ Object.keys(mimes).join(', ') }}
        </small>

        <div
            :class="classes"
            ref="dropZone"
        >
            <input
                :name="`${name}[file]`"
                :required="required && !file"
                @change="handleFileChanged"
                ref="file"
                type="file"
                value=""
            />

            <input
                :name="`${name}[action]`"
                ref="action"
                type="hidden"
                v-model="action"
            />

            <div
                v-if="!file"
                class="choose-overlay"
            >
                <h1 class="text-secondary">
                    <i class="fa fa-copy"></i>
                </h1>

                <template v-if="supportsDragAndDrop">
                    <h5 class="text-secondary">Drag File Here</h5>
                    <h6 class="text-primary">or click to browse your computer</h6>
                </template>

                <template v-else>
                    <h5 class="text-secondary">Click Here</h5>
                    <h6 class="text-primary">to browse your computer</h6>
                </template>
            </div>

            <div
                v-else
                class="file-overlay"
            >
                <a
                    v-if="file.url"
                    :href="file.url"
                    target="_blank"
                >
                    <img
                        :src="file.url"
                        v-if="isImage"
                    />
                    <i
                        class="fa fa-file"
                        v-else
                    ></i>
                </a>

                <h1
                    v-else
                    class="text-secondary"
                >
                    <i class="fa fa-file"></i>
                </h1>

                <h5 class="text-secondary">
                    {{ file.name }}
                </h5>

                <a
                    href="#"
                    class="text-danger h5"
                    @click.prevent="deselect"
                >
                    <i class="fa fa-trash"></i>
                </a>
            </div>
        </div>
    </div>
</template>

<style lang="scss">
    .drop-area {
        border: 1px solid #cccccc;
        border-radius: 0.25rem;
        color: #495057;
        display: block;
        position: relative;
        height: 150px;
        margin-bottom: 0.8rem;

        &.drop-area__over {
            background: #eeeeee;
        }

        img {
            max-width: 100%;
            height: 50px;
        }

        input {
            opacity: 0;
            cursor: pointer;
            z-index: 1;
        }

        .choose-overlay {
            pointer-events: none;
            padding: 20px;
            text-align: center;
            vertical-align: middle;
            z-index: 1;
        }

        .file-overlay {
            padding: 20px;
            text-align: center;
            vertical-align: middle;
            z-index: 2;
        }

        > input, > div {
            position: absolute;
            display: block;
            width: 100%;
            height: 100%;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
        }
    }
</style>

<script language="text/babel">
import Modernizr from 'modernizr';

export default {
    props: {
        name: String,
        required: {
            type: Boolean,
            default: false,
        },
        existingFile: [Object, Array],
        mimes: {
            type: Object,
            default: () => ({
                gif: 'image/gif',
                jpeg: 'image/jpeg',
                jpg: 'image/jpg',
                png: 'image/png',
            }),
        },
    },
    data() {
        return {
            isOver: false,
            hasFile: false,
            supportsDragAndDrop: true,
            file: null,
            action: null,
        };
    },
    mounted() {
        const isIe = window.navigator.userAgent.indexOf('MSIE ') !== -1;
        const isEdge = window.navigator.userAgent.indexOf('Edge/') !== -1;

        this.supportsDragAndDrop = (
            Modernizr.fileinput &&
            Modernizr.filereader &&
            Modernizr.hasEvent('drop', this.$refs.file) &&
            !isIe &&
            !isEdge
        );

        if (!_.isEmpty(this.existingFile)) {
            this.file = {
                name: this.existingFile.filename,
                url: this.existingFile.url,
            };

            this.hasFile = true;
        }

        if (this.supportsDragAndDrop) {
            this.$refs.dropZone.addEventListener('dragover', this.onDragOver, false);
            this.$refs.dropZone.addEventListener('dragleave', this.onDragLeave, false);
            this.$refs.dropZone.addEventListener('drop', this.onDrop, false);
        }
    },
    computed: {
        isImage() {
            if (!this.file || !this.file.url) {
                return false;
            }

            return /(jpg|gif|png|JPG|GIF|PNG|JPEG|jpeg)$/.test(this.file.url);
        },
        classes() {
            return {
                'drop-area': true,
                'drop-area__over': this.isOver,
            };
        },
    },
    methods: {
        onDragOver(event) {
            event.stopPropagation();
            event.preventDefault();

            this.isOver = true;
        },
        onDragLeave() {
            this.isOver = false;
        },
        onDrop() {
            this.isOver = false;
        },
        handleFileChanged(event) {
            if (this.$refs.file.files.length > 0) {
                const file = this.$refs.file.files[0];

                if (!_.includes(this.mimes, file.type)) {
                    event.stopPropagation();
                    event.preventDefault();

                    this.deselect();

                    Message.error(`Invalid file type '${file.type}'!`);

                    return;
                }

                this.file = {
                    name: file.name,
                };
                this.action = 'upload';
            } else {
                this.file = null;
                this.action = this.existingFile ? 'delete' : null;
            }
        },
        deselect() {
            if (this.hasFile && this.file.url === this.existingFile.url) {
                Ajax.get(`/files/delete/${this.existingFile.identifier}`);
                this.hasFile = false;
            }

            this.$refs.file.value = '';
            this.$refs.file.type = '';
            this.$refs.file.type = 'file';
            this.$refs.action.dispatchEvent(new Event('change', { 'bubbles': true }));

            this.file = null;
            this.action = this.existingFile ? 'delete' : null;
        },
    },
};
</script>
