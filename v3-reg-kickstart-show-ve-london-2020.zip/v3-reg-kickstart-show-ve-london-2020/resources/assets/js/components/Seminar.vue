<template>
    <div>
        <template v-if="mobile === true">
            <div class="event-time">
                {{ seminar.starts_at.format('HH:mm') }} - {{ seminar.ends_at.format('HH:mm') }}
            </div>

            <div
                class="event-capacity"
                v-if="seminar.capacity > 0"
            >
                <small>
                    {{ transUi('Seats Available') }}
                </small>
                -
                {{ seminar.spacesAvailable }}/{{ seminar.capacity }}
            </div>

            <div class="event-name">
                {{ seminar.title }}
            </div>

            <div
                class="event-booker-attending"
                v-if="seminar.lead_attendee_booking !== null"
            >
                <i
                    class="fa fa-square"
                    aria-hidden="true"
                ></i>
                <template v-if="seminar.lead_attendee_booking.status === 'in_basket'">
                    {{ transUi('In Basket') }}
                </template>
                <template v-else-if="seminar.lead_attendee_booking.status === 'awaiting_payment'">
                    {{ transUi('Awaiting Payment') }}
                </template>
                <template v-else>
                    {{ transUi('I\'m Attending') }}
                </template>
            </div>
        </template>

        <template v-else>
            <div class="event-time float-left">
                {{ seminar.starts_at.format('HH:mm') }} - {{ seminar.ends_at.format('HH:mm') }}
            </div>

            <div class="float-right">
                <i
                    class="fa fa-expand"
                    aria-hidden="true"
                ></i>
            </div>

            <div class="clearfix"></div>

            <div
                class="event-capacity"
                v-if="seminar.capacity > 0"
            >
                <small>
                    {{ transUi('Seats Available') }}
                </small>
                -
                {{ seminar.spacesAvailable }}/{{ seminar.capacity }}
            </div>

            <div class="event-name">
                {{ seminar.title }}
            </div>

            <div
                class="event-booker-attending"
                v-if="seminar.lead_attendee_booking !== null"
            >
                <i
                    class="fa fa-square"
                    aria-hidden="true"
                ></i>
                <template v-if="seminar.lead_attendee_booking.status === 'in_basket'">
                    {{ transUi('In Basket') }}
                </template>
                <template v-else-if="seminar.lead_attendee_booking.status === 'awaiting_payment'">
                    {{ transUi('Awaiting Payment') }}
                </template>
                <template v-else>
                    {{ transUi('I\'m Attending') }}
                </template>
            </div>

            <div class="event-details">
                <p v-html="seminar.description"></p>

                <div
                    class="event-cost"
                    v-if="seminar.product !== null && seminar.product.cost > 0"
                >
                    {{ seminar.product.total_formatted }}

                    <span class="vat">
                        (inc. {{ seminar.product.vat_formatted }} VAT)
                    </span>
                </div>

                <div
                    class="event-speakers"
                    v-if="seminarHasSpeakers(seminar)"
                >
                    <span>
                        {{ transUi('Speakers') }}:
                    </span>

                    <ul>
                        <li
                            v-for="speaker in seminar.speakers"
                            v-if="speaker.customer"
                        >
                            {{ speaker.customer.name }}
                        </li>
                    </ul>
                </div>

                <div
                    class="event-colleagues-attending"
                    v-if="seminarHasAttendees(seminar)"
                >
                    <span>
                        {{ transUi('Colleagues Attending') }}:
                    </span>

                    <ul>
                        <li v-for="attendee in seminar.managed_attendees">
                            {{ attendee.name }}
                        </li>
                    </ul>
                </div>
            </div>
        </template>
    </div>
</template>

<script>
export default {
    props: {
        seminar: {
            type: Object,
            required: true,
        },
        mobile: {
            type: Boolean,
            required: true,
        },
    },
    methods: {
        seminarHasAttendees(seminar) {
            return !_.isEmpty(seminar.managed_attendees);
        },
        seminarHasSpeakers(seminar) {
            return !_.isEmpty(seminar.speakers) && !_.isEmpty(_.filter(seminar.speakers, 'customer'));
        },
    },
};
</script>
