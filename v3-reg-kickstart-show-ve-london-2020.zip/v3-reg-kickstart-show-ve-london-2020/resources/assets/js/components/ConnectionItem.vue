<template>
    <div>
        <h6
            class="truncate text-center"
            :title="connection.name"
        >
            {{ connection.name }}
        </h6>

        <a
            :href="connection.profile_url"
            target="_blank"
            v-if="connection.profile_url"
        >
            <img
                class="img-thumbnail img-responsive center-block"
                width="100%"
                :src="connection.picture_url"
            />
        </a>

        <img
            class="img-thumbnail img-responsive center-block"
            :src="connection.picture_url"
            v-else
        />
    </div>
</template>

<script>
export default {
    props: ['connection'],
};
</script>
