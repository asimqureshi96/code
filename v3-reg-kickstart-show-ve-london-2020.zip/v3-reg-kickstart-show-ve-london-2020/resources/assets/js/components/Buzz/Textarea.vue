<template>
    <div>
        <label :class="['buzz-input', {'buzz-input__with-label': labelVisible, 'buzz-input__is-invalid': isInvalid}]">
            <span class="text-primary">
                {{ labelText }}
                <span
                    class="text-danger"
                    v-if="required"
                >
                    *
                </span>
            </span>

            <textarea
                :disabled="isDisabled"
                :id="name"
                :name="name"
                :placeholder="placeholderText"
                :required="required"
                v-model="myModel"
            />

            <input
                :name="name"
                :value="myModel"
                type="hidden"
                v-if="readOnly"
            >
        </label>

        <span
            v-if="hasMax"
            class="text-muted"
        >
            {{ remainingChars }} {{ transUi('characters left') }}
        </span>

        <error :identifier="myErrorIdentifier"/>
    </div>
</template>

<script>
import Base from './Base.vue';

export default {
    // @todo remove file after buzz-ui integrated
    extends: Base,
    props: {
        type: {
            type: String,
            default: 'text',
        },
        autofocus: {
            type: Boolean,
            default: false,
        },
        rules: {
            type: Object,
            default: () => {},
        },
        readOnly: {
            type: Boolean,
            default: false,
        },
    },
    data() {
        return {
            localValue: '',
        };
    },
    computed: {
        hasMax() {
            return (!(!this.rules || !this.rules.max));
        },
        remainingChars() {
            if (this.rules.max) {
                return this.rules.max - this.localValue.length;
            }

            return null;
        },
        isDisabled() {
            return this.disabled || this.readOnly;
        },
    },
    mounted() {
        if (this.autofocus) {
            this.$nextTick(() => this.focus());
        }
    },
    methods: {
        focus() {
            this.$refs.input.focus();
        },
    },
};
</script>
