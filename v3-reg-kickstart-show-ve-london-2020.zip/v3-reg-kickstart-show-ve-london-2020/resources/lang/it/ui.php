<?php

return [

    /*
    |--------------------------------------------------------------------------
    | UI translations
    |--------------------------------------------------------------------------
     */

    'Address Information'              => 'Informazioni sull\'indirizzo',
    'Are you sure?'                    => 'Sei sicuro?',
    'Back'                             => 'Indietro',
    'Cancel'                           => 'Annulla',
    'Change password'                  => 'Cambia la password',
    'Company'                          => 'Azienda',
    'Completion'                       => 'Completamento',
    'Confirm email'                    => 'Conferma email',
    'Confirm password'                 => 'Conferma password',
    'Confirm'                          => 'Conferma',
    'Contact details'                  => 'Dettagli del contatto',
    'Continue'                         => 'Continua',
    'Email'                            => 'E-mail',
    'Enter your desired login details' => 'Inserisci i dati di accesso desiderati',
    'Enter your personal details'      => 'Inserisci i tuoi dati personali',
    'First demographic'                => 'Prima demografia',
    'First name'                       => 'Nome di battesimo',
    'Invite via email'                 => 'Invito via email',
    'Job title'                        => 'Titolo di lavoro',
    'Last name'                        => 'Cognome',
    'Login information'                => 'Informazioni di accesso',
    'Miss'                             => 'Perdere',
    'Mr'                               => 'Sig',
    'Mrs'                              => 'Sig.ra',
    'Ms'                               => 'Signorina',
    'OK'                               => 'OK',
    'Optional demographic'             => 'Facoltativo demografico',
    'Other'                            => 'Altro',
    'Password'                         => 'Password',
    'Personal information'             => 'Informazione personale',
    'Please select'                    => 'Per favore seleziona',
    'Please specify'                   => 'Per favore specificare',
    'Prof'                             => 'Prof',
    'Registration completed!'          => 'La registrazione è stata completata!',
    'Success!'                         => 'Successo!',

    'Are you sure you want to change your registration? You will need to complete the registration process again.' => 'Sei sicuro di voler cambiare la tua registrazione? Dovrai completare di nuovo la procedura di registrazione.',

    'Please provide a password in order to access your tickets and make amendments to your booking' => 'Fornire una password per accedere ai tuoi biglietti e apportare modifiche alla tua prenotazione',

    'There are some errors with your input! Please check and try again.' => 'Ci sono degli errori con il tuo contributo! Si prega di verificare e riprovare.',

    'You are sure you want to proceed?' => 'Sei sicuro di voler procedere?',

];
