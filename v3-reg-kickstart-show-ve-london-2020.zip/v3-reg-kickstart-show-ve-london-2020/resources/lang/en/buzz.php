<?php

return [

    /*
    |-------------f-------------------------------------------------------------
    | Buzz config translations
    |--------------------------------------------------------------------------
     */

    'event'                     => [
        'name'  => 'VE London',
        'year'  => '2020',
        'date'  => '23rd & 24th September',
        'venue' => 'Old Billingsgate, London',
    ],

    'meta_description'          => "Register now for Venues + Events Live London 2020!",

    // Email invite
    'email_invite_subject'      => "Join me at Venues + Events Live London 2020!",
    'email_invite_message'      => "I'm going to Venues + Events Live London 2020!. Join me at the innovative and interactive annual exhibition. With some of the industry’s best exhibitors and a variety of features including exciting sessions and hands-on masterclasses.",

    // Linkedin invite
    'connection_invite_subject' => "Join me at Venues + Events Live London 2020!",
    'connection_invite_message' => "I’ve just registered for #VELive! Who’s coming? @VandELive.\n\nhttps://kickstart-visitor.localhost/?invite=INVITE_CODE",
    'linkedin_share_message'    => 'I’ve just registered for #VELive! Who’s coming? @VandELive.',

    // Twitter invite
    'twitter_share_message'     => 'I’ve just registered for #VELive! Who’s coming? @VandELive.',

];
