<answer
    @if(customer())
    :answer="{{ customer()->getAnswerByIdentifier('what-is-your-main-reason-for-attending-venues-events-live') ?? 'null' }}"
    @endif
    :question="{{ $questions['what-is-your-main-reason-for-attending-venues-events-live'] }}"
    :required="{{ in_array('what-is-your-main-reason-for-attending-venues-events-live', $required) ? 'true' : 'false' }}"
    :column-count="2"
></answer>

<answer
    :answer="{{ customer()->getAnswerByIdentifier('would-you-like-to-register-as-a-judge-for-canape-cup') ?? 'null' }}"
    :question="{{ $questions['would-you-like-to-register-as-a-judge-for-canape-cup'] }}"
    :required="{{ in_array('would-you-like-to-register-as-a-judge-for-canape-cup', $required) ? 'true' : 'false' }}"
></answer>
@if(!customer()->custom_status || !$type === 'xlist')
    <h5 class="required">Would you like to be registered for Venues & Events Live Manchester (29 September, Manchester Central)</h5>
    <answer
        :answer="{{ customer()->getAnswerByIdentifier('visitor-for-venues-events-live-manchester') ?? 'null' }}"
        :question="{{ $questions['visitor-for-venues-events-live-manchester'] }}"
        :show-title="false"
        :required="{{ in_array('visitor-for-venues-events-live-manchester', $required) ? 'true' : 'false' }}"
    ></answer>
        @endif

<answer
    :answer="{{ customer()->getAnswerByIdentifier('would-you-like-to-receive-a-regular-subscription-to-squaremeal') ?? 'null' }}"
    :question="{{ $questions['would-you-like-to-receive-a-regular-subscription-to-squaremeal'] }}"
    :required="{{ in_array('would-you-like-to-receive-a-regular-subscription-to-squaremeal', $required) ? 'true' : 'false' }}"
>
    <answer
        :answer="{{ customer()->getAnswerByIdentifier('how-would-you-like-to-receive-this') ?? 'null' }}"
        :question="{{ $questions['how-would-you-like-to-receive-this'] }}"
        :required="{{ in_array('how-would-you-like-to-receive-this', $required) ? 'true' : 'false' }}"
        slot="yes::after"
    ></answer>
</answer>

