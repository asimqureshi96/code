When you require to change specific blade file copy it from

`vendor/livebuzz/v3-reg-core/resources/views`

to this folder and make changes. 

You should only copy files that you need to override to reduce risk of missing  
vital fixes from v3-reg-core repository
