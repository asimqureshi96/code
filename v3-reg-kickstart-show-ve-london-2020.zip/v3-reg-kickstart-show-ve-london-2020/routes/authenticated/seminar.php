<?php

if (!config('buzz.seminars_enabled')) {
    return;
}

Route::get('/seminars', 'SeminarController@render')->name('seminars');

Route::group(['prefix' => '/seminar', 'as' => 'seminar::', 'middleware' => 'load-seminar'], function () {
    Route::get('{seminar_id?}', 'SeminarController@single')->name('single');

    if (config('buzz.seminars_colleague_enabled')) {
        Route::post('attach-colleagues{seminar_id?}', 'SeminarController@attachColleagues')->name('attach-colleagues');
        Route::group(['prefix' => '{customer_id}'], function () {
            Route::get('attach/{seminar_id?}', 'SeminarController@attachCustomer')->name('attach');
            Route::get('detach/{seminar_id?}', 'SeminarController@detachCustomer')->name('detach');
        });
    }

    Route::get('lead-attach/{seminar_id?}', 'SeminarController@attachLead')->name('lead-attach');
    Route::get('lead-detach/{seminar_id?}', 'SeminarController@detachLead')->name('lead-detach');
    Route::get('has-overlapping-meeting/{seminar_id?}/{customer_id?}', 'SeminarController@hasOverlappingMeeting')
        ->name('has-overlapping-meeting');
});

Route::group(['prefix' => '/paid-seminar', 'as' => 'paid-seminar::', 'middleware' => 'load-seminar'], function () {
    Route::get('{seminar_id?}', 'PaidSeminarController@single')->name('single');

    if (config('buzz.seminars_colleague_enabled')) {
        Route::post('attach-colleagues/{seminar_id?}', 'PaidSeminarController@attachColleagues')
            ->name('attach-colleagues');
        Route::group(['prefix' => '{customer_id}'], function () {
            Route::get('attach/{seminar_id?}', 'PaidSeminarController@attachCustomer')->name('attach');
            Route::get('detach/{seminar_id?}', 'PaidSeminarController@detachCustomer')->name('detach');
        });
    }

    Route::get('lead-attach/{seminar_id?}', 'PaidSeminarController@attachLead')->name('lead-attach');
    Route::get('lead-detach/{seminar_id?}', 'PaidSeminarController@detachLead')->name('lead-detach');
    Route::get('has-overlapping-meeting/{seminar_id?}/{customer_id?}', 'PaidSeminarController@hasOverlappingMeeting')
        ->name('has-overlapping-meeting');
});
