<?php

Route::get('lookup/address-by-postcode/{country}/{postcode}', 'LookupController@addressByPostcode');
Route::get('lookup/countries', 'LookupController@countries');
Route::get('lookup/ip2country', 'LookupController@ip2country');
