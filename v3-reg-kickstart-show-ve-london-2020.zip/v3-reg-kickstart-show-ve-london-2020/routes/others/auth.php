<?php

Route::group(['prefix' => 'auth', 'namespace' => 'Auth', 'as' => 'auth::'], function () {
    if (config('buzz.password_required')) {
        Route::get('login', 'LoginController@showLoginForm')->name('login');
        Route::post('login', 'LoginController@login')->name('login');
    }

    Route::get('logout', 'LoginController@logout')->name('logout');
    Route::get('login-via-signed-url', 'AuthController@getLoginViaSignedUrl')->name('login-via-signed-url');
});

if (!config('buzz.password_required')) {
    Route::group(['prefix' => 'auth', 'as' => 'auth::'], function () {
        Route::any('login', 'ProfileController@render')->name('login')->middleware('auth');
    });
}
