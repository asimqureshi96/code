<?php

namespace App\Exceptions;

use Buzz\Helpers\Exceptions\Handler as ConsumablesHandler;

/**
 * Class Handler
 *
 * @package App\Exceptions
 */
class Handler extends ConsumablesHandler
{
}