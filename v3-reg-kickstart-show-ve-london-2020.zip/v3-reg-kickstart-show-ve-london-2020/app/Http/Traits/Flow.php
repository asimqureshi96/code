<?php

namespace App\Http\Traits;

use Buzz\Control\Campaign\Customer;
use Buzz\Control\Campaign\Phone;
use Buzz\Control\Filter;
use Buzz\Control\Service;
use Buzz\Helpers\CopyCustomerData;
use RegCore\Http\Traits\Flow as BaseFlow;

trait Flow
{
    use BaseFlow;

    // Copy methods from BaseFlow if you need changing them
    // Paste them below this comment
    protected function complete()
    {
        $new_reg = false;

        if (customer()->status == 'incomplete') {
            $new_reg = true;
        }

        $type = registrationType();

        if ($type === 'xlist'){
            customer()->badge_type_id = 'xlist';
            customer()->status        = 'rejected';
            customer()->custom_status_id = 'xlist';
        } elseif ($type === 'supplier' || str_contains(strtolower(customer()->job_title),['sales','business development','commercial'])){
            customer()->badge_type_id = 'supplier';
            customer()->status        = 'pending';
        } elseif ($type === 'vip') {
            customer()->badge_type_id = 'vip';
            customer()->status        = 'pending';
        }elseif ($type === 'visitor' && str_contains(strtolower(customer()->email),['@hotmail','@gmx','@googlemail','@mac','@facebook','@verizon','@aol','@yahoo','@msn','@gmail','@gmail','@icloud','@live','@outlook','@live','@sky','@virgin','@talk'])) {
            customer()->badge_type_id = 'visitor';
            customer()->status        = 'pending';
        } else {
            customer()->badge_type_id = 'visitor';
            customer()->status        = 'active';
        }

        customer()->save();
        customer()->completeFlow();


        if (config('buzz.onsite')) {
            liveControlEvent('customer_completed', ['barcode' => customer()->barcode]);
            auth()->logout();

            return redirect()->route('step1');
        }

        session()->flash('flash_message', [
            'type'    => 'success',
            'title'   => transUi('Success!'),
            'message' => transUi('Registration completed!'),
        ]);

        if(customer()->getAnswerByIdentifier('visitor-for-venues-events-live-manchester')){
            ## If new registration and also registering for VE Manchester we need to save customer in VE Manchester campaign
            if (hasAnswerOptionSaved('visitor-for-venues-events-live-manchester', 'yes') && $new_reg) {
                 Service::setCampaign('venuesandevents-manchester-2020');
                 Service::setStream('visitor');

                $check_exists = (new Customer())
                    ->first((new Filter())
                        ->add('source_id', 'is', customer()->id)
                        ->add('status', 'is not', 'cancelled')
                    );

                if (!$check_exists) {
                    $copy_customer = new Customer();

                    $copy_customer->title            = customer()->title;
                    $copy_customer->first_name       = customer()->first_name;
                    $copy_customer->last_name        = customer()->last_name;
                    $copy_customer->job_title        = customer()->job_title;
                    $copy_customer->company          = customer()->company;
                    $copy_customer->email            = customer()->email;
                    $copy_customer->source_id        = customer()->id;
                    $copy_customer->status           = 'incomplete';
                    $copy_customer->custom_status_id = 've-london-registration';

                    $copy_customer->expand(config('auth.relations'))->save();

                    $copy_customer->startFlow();

                    $copy_tel = customer()->phones->where('type', 'telephone')->first()->number;

                    $telephone = (new Phone());

                    $telephone->type   = 'telephone';
                    $telephone->number = $copy_tel;

                    $telephone->associate($copy_customer);
                    $telephone->save();

                    if (customer()->phones->where('type', 'mobile')->first()) {
                        $copy_mobile = customer()->phones->where('type', 'mobile')->first()->number;

                        $mobile = (new Phone());

                        $mobile->type   = 'mobile';
                        $mobile->number = $copy_mobile;

                        $mobile->associate($copy_customer);
                        $mobile->save();
                    }

                    app(CopyCustomerData::class)->address($copy_customer);
                }

                Service::setCampaign('venuesandevents-london-2020');
                Service::setStream('visitor');
            }
        }

        return redirect()->route('thanks');
    }
}


