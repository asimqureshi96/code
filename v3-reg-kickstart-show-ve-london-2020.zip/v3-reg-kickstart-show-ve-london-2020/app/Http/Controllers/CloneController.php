<?php

namespace App\Http\Controllers;

use App\Http\Traits\Flow;
use RegCore\Http\Controllers as Core;

class CloneController extends Core\CloneController
{
    use Flow;
}
