<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step7Controller extends Step\Step5Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 7;

    protected function getRequired()
    {
        return [
            'admissions-policy',
        ];
    }

    protected function getQuestions()
    {
        return [
            'admissions-policy',
        ];
    }

    public function render(QuestionHelper $questionHelper)
    {
        $type = registrationType();

        $questions = $questionHelper->getByIdentifiers($this->getQuestions());

        $required = $this->getRequired();

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required', 'type')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {

        $this->handleFlow();

        $required = $this->getRequired();

        if (str_contains(strtolower(customer()->email),['@a-listevents','@bnceventshows','@hirespace','@venuesearchlondon','@venueview'])) {
        addProperty('type','xlist');
        }

        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        return $this->complete();
    }
}

