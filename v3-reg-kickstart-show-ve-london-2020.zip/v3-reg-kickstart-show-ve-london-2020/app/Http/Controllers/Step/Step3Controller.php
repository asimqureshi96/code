<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step3Controller extends Step\Step3Controller
{
    use Traits\Flow;
    use Traits\Step;


    protected function getRequired()
    {
        return [
            'what-is-your-level-of-seniority',
            'what-percentage',
            'how-many-events-do-you-organise-each-year',
            'what-size-events-do-you-hold-on-average-attendance',
            'what-is-your-total-annual-budget-for-events',
        ];
    }

    protected function getQuestions()
    {
        return [
            'what-is-your-level-of-seniority',
            'what-percentage',
            'how-many-events-do-you-organise-each-year',
            'what-size-events-do-you-hold-on-average-attendance',
            'what-is-your-total-annual-budget-for-events',
        ];
    }
    protected function getRequiredSupplier()
    {
        return [
            'which-type-of-events-do-you-supply-services-to',
            'venue-supplier-do-you-represent',
            'main-reason-for-attending-venues-events-live-supplier',
        ];
    }
    protected function getQuestionsSupplier()
    {
        return [
            'which-type-of-events-do-you-supply-services-to',
            'venue-supplier-do-you-represent',
            'main-reason-for-attending-venues-events-live-supplier',
        ];
    }

    protected function getRequiredSpecific($type)
    {
        if ($type === 'supplier') {
            return $this->getRequiredSupplier();
        }
        else{
            return $this->getRequired();
        }
    }

    protected function getQuestionsSpecific($type)
    {
        if ($type === 'supplier') {
            return $this->getQuestionsSupplier();
        }
        else
            return $this->getQuestions();
    }

    /**
     * @param QuestionHelper $questionHelper
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Buzz\Helpers\Exceptions\Error
     */
    public function render(QuestionHelper $questionHelper)
    {
        $type = registrationType();


        $questions = $questionHelper->getByIdentifiers($this->getQuestionsSpecific($type));
        $required = $this->getRequiredSpecific($type);

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required','type')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {
        $type = registrationType();

        if (isAnswered('what-is-your-total-annual-budget-for-events',
            ['100-k-250-k', '250-k-500-k', '500-k-1-m', '1-m'])
        ) {
            addProperty('type', 'vip');
        } elseif(isAnswered('what-is-your-total-annual-budget-for-events',['50-k-100-k','10-k-50-k','up-to-10-k'])) {
            addProperty('type', 'visitor');
        }

        if (str_contains(strtolower(customer()->email),['@a-listevents','@bnceventshows','@hirespace','@venuesearchlondon','@venueview'])) {
            addProperty('type','xlist');
        }

        $this->handleFlow();

        $required = $this->getRequiredSpecific($type);

        $answerHelper->answerMany($this->getQuestionsSpecific($type), request('questions'), $required);

        return $this->next();
    }
}
