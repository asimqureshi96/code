<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step4Controller extends Step\Step4Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 4;

    protected function getRequired()
    {
        return [
            'where-do-you-hold-your-events',
            'are-you-responsible-for-booking-travel-if-so-please-let-us-know-which-options',
            'do-you-organise-events-outside-of-london',
            'what-type-of-events-do-you-organise',
        ];
    }

    protected function getQuestions()
    {
        return [
            'where-do-you-hold-your-events',
            'if-overseas-is-chosenhow-many-overseas-events-do-you-organise',
            'if-overseas-is-chosen-where-do-you-hold-your-overseas-events',
            'are-you-responsible-for-booking-travel-if-so-please-let-us-know-which-options',
            'do-you-organise-events-outside-of-london',
            'what-type-of-events-do-you-organise',
            ];
    }

    protected function getRequiredSupplier()
    {
        return [
            'admissions-policy',
            'would-you-like-to-receive-a-regular-subscription-to-squaremeal',
        ];
    }

    protected function getQuestionsSupplier()
    {
        return [
            'how-would-you-like-to-receive-this',
            'admissions-policy',
            'would-you-like-to-receive-a-regular-subscription-to-squaremeal',
        ];
    }

    protected function getRequiredSpecific($type)
    {
        if ($type === 'supplier') {
            return $this->getRequiredSupplier();
        } else {
            return $this->getRequired();
        }
    }

    protected function getQuestionsSpecific($type)
    {
        if ($type === 'supplier') {
            return $this->getQuestionsSupplier();
        } else {
            return $this->getQuestions();
        }
    }

    public function render(QuestionHelper $questionHelper)
    {
        $type = registrationType();

        $questions = $questionHelper->getByIdentifiers($this->getQuestionsSpecific($type));

        $required = $this->getRequiredSpecific($type);

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required', 'type')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {
        $type = registrationType();
        if (isAnswered( 'would-you-like-to-receive-a-regular-subscription-to-squaremeal', 'yes')) {
            $required[] = 'how-would-you-like-to-receive-this';
        }
        if (isAnswered('what-is-your-total-annual-budget-for-events',
            ['100-k-250-k', '250-k-500-k', '500-k-1-m', '1-m'])
        ) {
            addProperty('type', 'vip');
        } elseif(isAnswered('what-is-your-total-annual-budget-for-events',['50-k-100-k','10-k-50-k','up-to-10-k'])) {
            addProperty('type', 'visitor');
        }

        $this->handleFlow();

        $required = $this->getRequiredSpecific($type);

        if (isAnswered('where-do-you-hold-your-events', 'overseas')) {
            $required[] = 'if-overseas-is-chosenhow-many-overseas-events-do-you-organise';
            $required[] = 'if-overseas-is-chosen-where-do-you-hold-your-overseas-events';
        }
        $answerHelper->answerMany($this->getQuestionsSpecific($type), request('questions'), $required);

        if ($type === 'supplier') {
            return $this->complete();
        } else {
            return $this->next();
        }
    }
}
