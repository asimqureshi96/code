<?php

namespace App\Http\Controllers\Step;

use App\Http\Traits;
use Buzz\Helpers\AnswerHelper;
use Buzz\Helpers\QuestionHelper;
use RegCore\Http\Controllers\Step;

class Step6Controller extends Step\Step5Controller
{
    use Traits\Flow;
    use Traits\Step;

    protected $step = 6;

    protected function getRequired()
    {
        return [
            'would-you-like-to-register-as-a-judge-for-canape-cup',
            'what-is-your-main-reason-for-attending-venues-events-live',
            'would-you-like-to-receive-a-regular-subscription-to-squaremeal',
        ];
    }

    protected function getQuestions()
    {
        return [
            'how-would-you-like-to-receive-this',
            'what-is-your-main-reason-for-attending-venues-events-live',
            'would-you-like-to-register-as-a-judge-for-canape-cup',
            'visitor-for-venues-events-live-manchester',
            'would-you-like-to-receive-a-regular-subscription-to-squaremeal',
        ];
    }

    public function render(QuestionHelper $questionHelper)
    {
        $type = registrationType();

        $questions = $questionHelper->getByIdentifiers($this->getQuestions());

        $required = $this->getRequired();

        return view(
            'step',
            ['step' => $this->step] + compact('questions', 'required', 'type')
        );
    }

    public function save(AnswerHelper $answerHelper)
    {

        $this->handleFlow();

        $required = $this->getRequired();
        if (!customer()->custom_status_id){
            $required[] = 'visitor-for-venues-events-live-manchester';
        }

        if (isAnswered( 'would-you-like-to-receive-a-regular-subscription-to-squaremeal', 'yes')) {
            $required[] = 'how-would-you-like-to-receive-this';
        }
        if (str_contains(strtolower(customer()->email),['@a-listevents','@bnceventshows','@hirespace','@venuesearchlondon','@venueview'])) {
            addProperty('type','xlist');
        }


        $answerHelper->answerMany($this->getQuestions(), request('questions'), $required);

        return $this->next();
    }
}

