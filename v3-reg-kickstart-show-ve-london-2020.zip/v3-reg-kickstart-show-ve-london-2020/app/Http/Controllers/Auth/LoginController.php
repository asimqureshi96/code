<?php

namespace App\Http\Controllers\Auth;

use RegCore\Http\Controllers\Auth;
use App\Http\Traits\Flow;

class LoginController extends Auth\LoginController
{
    use Flow;
}
