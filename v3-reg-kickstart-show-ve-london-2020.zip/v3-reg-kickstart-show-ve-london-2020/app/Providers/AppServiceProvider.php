<?php

namespace App\Providers;

use App;
use Buzz\Control\Service;
use Illuminate\Support\ServiceProvider;
use Maknz\Slack\Client as Slack;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        if (env('TRUSTED_PROXIES')) {
            app('request')->setTrustedProxies(explode(',', env('TRUSTED_PROXIES')));
        }
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(Slack::class, function () {
            return new Slack(config('slack.endpoint'), [
                'channel'                 => config('slack.channel'),
                'username'                => config('slack.username'),
                'icon'                    => config('slack.icon'),
                'link_names'              => config('slack.link_names'),
                'unfurl_links'            => config('slack.unfurl_links'),
                'unfurl_media'            => config('slack.unfurl_media'),
                'allow_markdown'          => config('slack.allow_markdown'),
                'markdown_in_attachments' => config('slack.markdown_in_attachments'),
            ]);
        });

        if (config('buzz.paid_show')) {
            $relations = config('auth.relations');
            array_push($relations, 'baskets');
            config(['auth.relations' => $relations]);
        }

        Service::setApiKey(config('buzz.api_key'));
        Service::setDomain(config('buzz.api_domain'));
        Service::setProtocol(config('buzz.api_protocol'));
        Service::setGateway(config('buzz.gateway'));
        Service::setOrganization(config('buzz.organization'));
        Service::setCampaign(config('buzz.campaign'));
        Service::setLanguage(app()->getLocale());
        Service::setVerifySsl(app()->environment('local') || config('buzz.api_proxy') ? false : true);
        Service::setProxy(config('buzz.api_proxy'));
        Service::setStream(config('buzz.stream'));
    }
}
