<?php

namespace App\Listeners;

use RegCore\Listeners;

class InviteResolver extends Listeners\InviteResolver
{
}
